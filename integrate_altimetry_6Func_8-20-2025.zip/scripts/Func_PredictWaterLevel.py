import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from prophet import Prophet
# from prophet.diagnostics import cross_validation
# from prophet.serialize import model_to_json, model_from_json
# from prophet.diagnostics import generate_future_df
# from prophet.legacy import Prophet

from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller
import numpy as np
import pandas as pd
# from cmdstanpy import install_cmdstan
# import inspect
# import ctypes

def predict_water_level(obs_water_levels_path_name:str, SARIMA:bool, days:int, output_dir:str, display_prediction: bool):
    if SARIMA: 
        predicted_timeSeries: pd.DataFrame = predict_water_level_sarimax(obs_water_levels_path_name, days, display_prediction)
        predicted_timeSeries.to_csv(output_dir + r'\predicted_time_series_SARIMA.csv')
    else: 
        # reinstall_cmdstan()
        # ctypes.windll.user32.MessageBoxW(0, inspect.getfile(cmdstanpy), 'ok so far 1', 1)
        predicted_timeSeries: pd.DataFrame = predict_water_level_prophet(obs_water_levels_path_name,days, display_prediction)
        predicted_timeSeries.to_csv(output_dir + r'\predicted_time_series_Prophet.csv')

    return None

def predict_water_level_sarimax(obs_water_levels_path_name:str, days: int, display_Prediction:bool):
    #read observed time sereis from csv file
    df = load_and_prepare_obs_data(obs_water_levels_path_name, date_col='date', value_col='waterLevels_cal')
    #after reading, 'ds' represents datetime, 'y' represents water level

    #only keep the date and water level columns and drop all others
    df = df[['ds','y']]
    # df = df.replace([np.inf, -np.inf], np.nan).dropna()
    # Remove rows with missing waterLevels_cal or waterLevels_ori
    df = df.dropna(subset=['y']).copy()
    # df['y'] = df['y'].clip(lower=df['y'].quantile(0.01), upper=df['y'].quantile(0.99))
    
    # Multiple water level measurements provided by different satellites
    df = df.groupby('ds').mean()
    #after groupby, 'ds' is set as index automatically
    # df.set_index('ds', inplace=True)

    #normalize the water levels
    # df['y'] = (df_['y'] - df['y'].mean()) / df['y'].std()  # Scale

    # Resample to daily frequency with unlimited interpolation, 'D' means daily
    df_daily = df.resample('D').interpolate(method='time')  # Time-weighted interpolation

    #After resampling, check stationarity but don't create separate series
    p_value = adfuller(df_daily['y'].dropna())[1]
    d = 1 if p_value > 0.05 else 0  # Determine differencing order

    p = 1  # AR order (PACF cutoff at lag 1)
    q = 1  # MA order (ACF cutoff at lag 1)

    # Check for seasonality (assuming daily data)
    # Look for spikes at lag 365 in ACF/PACF
    seasonal_p = 0  # Seasonal AR
    seasonal_d = 1  # Seasonal differencing
    seasonal_q = 0  # Seasonal MA
    m = 365         # Annual seasonality

    # #Train/test split
    # train_size = int(len(df_daily) * 0.8)
    # train = df_daily.iloc[:train_size]
    # test = df_daily.iloc[train_size:]

    model = SARIMAX(df_daily['y'].last('2Y'), #Recent 2 years. #train['y']
                order=(p, d, q),
                seasonal_order=(seasonal_p, seasonal_d, seasonal_q, m),
                enforce_stationarity=True,
                enforce_invertibility=True)

    results = model.fit(method='nm',
                   maxiter=50,
                   disp=False)
    print(results.summary())

    forecast = results.get_forecast(steps=days)#len(test))
    forecast_mean = forecast.predicted_mean
    conf_int = forecast.conf_int()

    
    df_output = pd.merge(forecast_mean, conf_int, left_index = True, right_index = True)
    df_output.reset_index(drop=False, inplace =True)
    df_output.rename(columns={'index':'date','lower y':'conf_int_95%_lower', 'upper y':'conf_int_95%_upper'}, inplace = True)

    df.reset_index(drop= False, inplace = True)
    if display_Prediction:
        plot_observed_vs_predicted(df, df_output,False)


    # # Calculate MAE
    # # # mae = mean_absolute_error(test['water_level'], forecast_mean)
    # # # print(f"\nMAE: {mae:.3f}")

    # plt.figure(figsize=(14, 7))

    # # Plot original data as points
    # plt.scatter(df_daily.index, df_daily['y'], 
    #             label='Original Data', 
    #             color='blue', 
    #             marker='o',       # Circle markers
    #             alpha=0.7,
    #             s=15)            # Marker size

    # # Plot forecasted values as points
    # plt.scatter(forecast_mean.index, forecast_mean, 
    #             label='Forecast', 
    #             color='red', 
    #             marker='s',       # Square markers
    #             s=20)            # Slightly larger

    # # Still show confidence intervals as area
    # plt.fill_between(conf_int.index,
    #                 conf_int.iloc[:, 0],
    #                 conf_int.iloc[:, 1],
    #                 color='pink', alpha=0.3, label='95% CI')

    # # Customizations
    # plt.title(f"Water Level Forecast (Point Visualization)\nSARIMAX({p},{d},{q})({seasonal_p},{seasonal_d},{seasonal_q},{m})")
    # plt.xlabel('Date')
    # plt.ylabel('Water Level (m)')
    # plt.legend()
    # plt.grid(True, linestyle=':', alpha=0.5)
    # plt.gcf().autofmt_xdate()  # Auto-rotate dates
    # plt.tight_layout()
    # plt.show()
    
    return df_output

def predict_water_level_prophet(obs_water_levels_path_name:str, days: int, display_Prediction:bool):
    #read observed time sereis from csv file
    df = load_and_prepare_obs_data(obs_water_levels_path_name, date_col='date', value_col='waterLevels_cal')
    # df['ds'] = df['ds'].apply(lambda x: x.to_pydatetime())

    # df = df.replace([np.inf, -np.inf], np.nan).dropna()
    # Remove rows with missing waterLevels_cal or waterLevels_ori
    df = df.dropna(subset=['y']).copy()
    # df['y'] = df['y'].clip(lower=df['y'].quantile(0.01), upper=df['y'].quantile(0.99))

    # # Group by trend bins (e.g., low/medium/high water levels)
    # # If std ~constant: Use 'additive'.
    # # If std increases with level: Use 'multiplicative'.
    # bins = pd.qcut(df_obs_time_series['y'], q=6)  # 3 quantile groups
    # seasonal_std = df_obs_time_series.groupby(bins)['y'].std()
    # print(seasonal_std)
    

    # df_obs_time_series = df_obs_time_series.dropna()
    # df_obs_time_series = df_obs_time_series.replace([np.inf, -np.inf], np.nan).dropna()

    # # Check for remaining issues
    # print(df_obs_time_series.isnull().sum())
    # print(df_obs_time_series.describe())

    # # Plot raw data
    # df_obs_time_series.plot(x='ds', y='y', figsize=(12,6))
    # plt.title('Water Level Raw Data Check')
    # plt.show()
    # print(df.dtypes)

    #normalize the water levels
    # df_obs_time_series['y'] = (df_obs_time_series['y'] - df_obs_time_series['y'].mean()) / df_obs_time_series['y'].std()  # Scale

    model = Prophet(
    yearly_seasonality= True,   # Auto-detect annual cycles (critical for water levels)
    weekly_seasonality= False,
    daily_seasonality=False,   # Disable if no daily patterns
    seasonality_mode="additive", # Use "multiplicative" if cycles scale with trend
    # changepoint_prior_scale=0.01
    )



    # model.add_seasonality(
    # name='yearly', 
    # period=365.25, 
    # fourier_order=4  # Reduced complexity
    # )

    model.fit(df)

    # print(inspect.getfile(cmdstanpy))

    future = model.make_future_dataframe(periods=days, freq="D")  # Daily forecast
    forecast = model.predict(future)

    future = model.make_future_dataframe(periods=days, freq="D")  # Daily forecast
    forecast = model.predict(future)

    index_forecast = (len(forecast)-days)
    df_output = forecast[index_forecast:]
    df_output = df_output[['ds','yhat','yhat_lower','yhat_upper']]
    df_output.reset_index(drop= True, inplace= True)
    df_output.rename(columns={'ds':'date',
                              'yhat': 'predicted_mean',
                              'yhat_lower':'conf_int_95%_lower', 
                              'yhat_upper':'conf_int_95%_upper'}, inplace= True)


    if display_Prediction: plot_observed_vs_predicted(df, df_output, True)
    # # Plot components
    # fig1 = model.plot(forecast)            # Trend + forecast
    # fig2 = model.plot_components(forecast)  # Breakdown of seasonality

    return df_output

def load_and_prepare_obs_data(filepath, date_col='date', value_col='water_level'):
    """
    Load water level data from a CSV file and prepare it as a time series.
    
    Args:
        filepath (str): Path to the CSV file
        date_col (str): Name of the date column
        value_col (str): Name of the water level column
        
    Returns:
        pd.Series: Time series of water levels with datetime index
    """
    df = pd.read_csv(filepath)#, parse_dates=[date_col], date_parser=pd.to_datetime)
    # df[date_col] = df[date_col].dt.to_pydatetime()
    df[date_col] = pd.to_datetime(df[date_col])
    # df.set_index(date_col, inplace=True)
    # ts = df[value_col]

    #prophet must have columns "ds" and "y" with the dates and values respectively.
    df.rename(columns={date_col:'ds',value_col:'y'}, inplace=True)
    df.sort_values(by='ds', ascending= True, inplace=True)
    df.reset_index(inplace= True, drop= True)
    return df

def plot_observed_vs_predicted(df_obs, df_pred, is_prophet:bool):
    """
    Plots observed vs predicted water levels with 95% confidence intervals.
    
    Parameters:
    - df_obs: DataFrame with columns ['ds', 'y']
    - df_pred: DataFrame with columns ['date', 'predicted_mean', 'conf_int_95%_lower', 'conf_int_95%_upper']
    """
    # Clean and prepare data
    df_obs = df_obs.dropna(subset=['ds', 'y']).copy()
    df_pred = df_pred.dropna(subset=['date', 'predicted_mean', 'conf_int_95%_lower', 'conf_int_95%_upper']).copy()

    df_obs['ds'] = pd.to_datetime(df_obs['ds'])
    df_pred['date'] = pd.to_datetime(df_pred['date'])

    df_obs = df_obs.sort_values('ds')
    df_pred = df_pred.sort_values('date')

    # Setup figure and axis
    fig, ax = plt.subplots(figsize=(8, 3))
    fig.patch.set_facecolor('white')
    ax.set_facecolor('#e0e0e0')

    # Styled spines
    for spine in ['top', 'right', 'bottom', 'left']:
        ax.spines[spine].set_visible(True)
        ax.spines[spine].set_color('#666666')

    ax.tick_params(axis='both', labelsize=11)
    for label in (ax.get_xticklabels() + ax.get_yticklabels()):
        label.set_fontname('Times New Roman')

    # Dashed grid lines (optional)
    ax.grid(True, linestyle='--', linewidth=0.3, color='gray', alpha=0.3)

    # Plot the confidence interval and capture the handle
    conf_fill = ax.fill_between(
        df_pred['date'],
        df_pred['conf_int_95%_lower'],
        df_pred['conf_int_95%_upper'],
        color="#53c7ee",
        alpha=0.4,
        label='95% Confidence Interval'
    )

    # Observed water levels (hollow red)
    obs_scatter = ax.scatter(df_obs['ds'], df_obs['y'],
                             facecolor='none',
                             edgecolor='#d62728',
                             linewidth=0.8,
                             s=8,
                             label='Observed',
                             zorder=3)

    # Predicted water levels (hollow blue)
    pred_scatter = ax.scatter(df_pred['date'], df_pred['predicted_mean'],
                              facecolor='none',
                              edgecolor='#1f77b4',
                              linewidth=0.8,
                              s=8,
                              label='Predicted',
                              zorder=4)

    # Titles and labels
    if is_prophet: ax.set_title('Observed vs Predicted Water Levels [Prophet]', fontsize=13,
                 fontweight='bold', fontname='Times New Roman')
    else: ax.set_title('Observed vs Predicted Water Levels [SARIMA]', fontsize=13,
                 fontweight='bold', fontname='Times New Roman')
    ax.set_xlabel('Date', fontsize=11, fontweight='bold', fontname='Times New Roman')
    ax.set_ylabel('Water Level (m)', fontsize=11, fontweight='bold', fontname='Times New Roman')

    # Legend
    legend = ax.legend(handles=[obs_scatter, pred_scatter, conf_fill],
                       frameon=True, loc='best')
    legend.get_frame().set_facecolor('#f5f5f5')
    legend.get_frame().set_edgecolor('#666666')
    for text in legend.get_texts():
        text.set_fontname('Times New Roman')
        text.set_fontweight('bold')
    
    # Show full date on x-axis without rotation
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))

    # Reduce tick label size (especially x-axis)
    ax.tick_params(axis='x', labelsize=9)
    
    plt.tight_layout()
    plt.show()
