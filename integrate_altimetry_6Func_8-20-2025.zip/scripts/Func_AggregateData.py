import geopandas as gpd
import pandas as pd
from itertools import product
import numpy as np
import os
import xarray as xs
from pyproj import CRS
from datetime import datetime
from geocube.api.core import make_geocube
from scipy import stats
import netCDF4

#function to aggregate the altimetry data
def aggregate_altimetry(parsed_profile_altimetry_path:str, swot_raster_path: str, lake_poly_path:str, cell_size:float, aggre_median:bool, output_folder:str):
    #save the path of the parsed profile altimetry data to a temp txt file. This will be used in the 4th step to load the parsed file.
    with open(output_folder + r'\temp_path.txt', 'w') as file:
        file.write(parsed_profile_altimetry_path)

    #read the min and max elev
    minHt = 0
    maxHt = 0
    with open(parsed_profile_altimetry_path + r'\temp_elevRange.txt','r') as file:
        line = file.readline().strip()
        str_values = line.split(',')
        decimal_values = [float(value) for value in str_values]
        minHt = decimal_values[0]
        maxHt = decimal_values[1]

    #Generate grid layer 
    # Load lake polygon
    lake_shp = gpd.read_file(lake_poly_path)#, drivers = 'shapefile')
    #convert from wgs84 to UTM projected crs
    lake_shp_reproj = lake_shp.to_crs(lake_shp.estimate_utm_crs())
    # #get lake extent
    # LakeBound=lake_shp_reproj.total_bounds
    # lake_minLon = LakeBound[0]
    # lake_maxLon = LakeBound[2]
    # lake_minLat = LakeBound[1]
    # lake_maxLat = LakeBound[3]

    #cell_size in km
    grid = generate_grid(lake_shp_reproj, cell_size * 1000)
    # grid = gpd.read_file(r'D:\GoogleDrive_AppState\FundedProjects\USAID_NASA_2023_2026\PyTools\output\grid_test.shp', drivers = 'shapefile')
    
    aggregate_profile_Altimetry(parsed_profile_altimetry_path, grid, output_folder)
    
    is_SSH = checkIfSSH(swot_raster_path)
    
    if is_SSH: 
        resample_SWOT_SSH_Raster(swot_raster_path,grid,lake_shp,output_folder, minHt, maxHt)
    else: 
        #extract and aggregate SWOT raster (250 m) data
        resample_SWOT_HR_Raster(swot_raster_path,grid,lake_shp,aggre_median,output_folder, minHt, maxHt)
        # resampledSWOT_grid = gpd.read_file(r'D:\Data\Altimetry_LakeVictoria\SWOT_Raster\SWOT_HR250m_vic_resampled.shp', drivers = 'shapefile')
    
    # Save the grid to a file
    # grid.to_file("grid_layer.shp", driver="shapefile")
    
    return None

def aggregate_profile_Altimetry(parsed_profile_altimetry_path:str,grid_layer:gpd.GeoDataFrame,output_folder:str):
    grid_layer = grid_layer[['Grid_ID','geometry']]
    #the output
    out_grid_Sen3A_shp:gpd.GeoDataFrame = grid_layer.copy(deep=True) 
    out_grid_Sen3B_shp:gpd.GeoDataFrame = grid_layer.copy(deep=True)
    out_grid_SWOT_n_shp:gpd.GeoDataFrame = grid_layer.copy(deep=True) 
    out_grid_Sen6_shp:gpd.GeoDataFrame = grid_layer.copy(deep=True) 
    out_grid_JA3_shp:gpd.GeoDataFrame = grid_layer.copy(deep=True)

    out_grid_Sen3A_csv:pd.DataFrame = grid_layer.copy(deep=True).drop(columns=['geometry']) 
    out_grid_Sen3B_csv:pd.DataFrame = grid_layer.copy(deep=True).drop(columns=['geometry']) 
    out_grid_SWOT_n_csv:pd.DataFrame = grid_layer.copy(deep=True).drop(columns=['geometry']) 
    out_grid_Sen6_csv:pd.DataFrame = grid_layer.copy(deep=True).drop(columns=['geometry']) 
    out_grid_JA3_csv:pd.DataFrame = grid_layer.copy(deep=True).drop(columns=['geometry']) 

    # #the standard deviation of each pass
    # out_allAlti_std = pd.DataFrame(columns=['date','mission','pass','std'])
    
    #read in parsed altimetry data and estimate the biases with reference to SWOT
    #read in the parsed altimetry csv files
    ls_alt_csv = []
    all_alt_points = pd.DataFrame()
    for file in os.listdir(parsed_profile_altimetry_path):
        if file.endswith('.csv') and 'Altimetry_Footprints' in file:
            ls_alt_csv.append(file)
            temp_df = pd.read_csv(os.path.join(parsed_profile_altimetry_path,file), index_col=0)
            if all_alt_points.empty: all_alt_points = temp_df
            else: all_alt_points = pd.concat([all_alt_points, temp_df],ignore_index=True)      
    
    all_alt_points.reset_index(drop=True,inplace=True)
    all_alt_points['date'] = (pd.to_datetime(all_alt_points['date'],format='%Y-%m-%d')).apply(lambda x:x.date())
    
    #Create geodataframe for points
    alt_pts_shp = gpd.GeoDataFrame(all_alt_points, geometry=gpd.points_from_xy(all_alt_points['longitude'],all_alt_points['latitude']), crs='epsg:4326')
    
    grid_layer_reproj = grid_layer.to_crs('epsg:4326')
    #spatial join the grid ID to each point
    all_alt_points_gridID = gpd.sjoin(alt_pts_shp, grid_layer_reproj, how = 'left',predicate='within')
    all_alt_points_gridID = all_alt_points_gridID[(~np.isnan(all_alt_points_gridID['Grid_ID']))]
    all_alt_points_gridID = all_alt_points_gridID.drop(columns = ['geometry','index_right']).reset_index(drop=True)
    
    # #get the list of grid cell IDs
    # cell_IDS = np.sort(all_alt_points_gridID['Grid_ID'].unique())
    
    #get the list of missions
    mission_ls = all_alt_points_gridID['mission'].unique()
    for mission in mission_ls:
        #get all the points collected by mission
        allPnts_mission = all_alt_points_gridID[all_alt_points_gridID['mission'] == mission]
        
        #get all the pass
        pass_ls = np.sort(allPnts_mission['pass'].unique())
        for eachPass in pass_ls:
            allPnts_pass = allPnts_mission[allPnts_mission['pass'] ==eachPass]
            strPass = str(eachPass).zfill(3)
            
            #get all the dates
            date_ls = np.sort(allPnts_pass['date'].unique())
            for eachDate in date_ls:
                allPnts_date = allPnts_pass[allPnts_pass['date'] == eachDate].copy(deep = True)

                allPnts_date = allPnts_date[allPnts_date['MAD_score']<3]
                #if there are fewer than 3 points, skip
                if allPnts_date.shape[0] < 3: continue

                allPnts_std = allPnts_date[['ht_egm08']].std().values[0]

                # #columns=['date','mission','pass','std']
                # out_allAlti_std.loc[out_allAlti_std.shape[0]]= [eachDate, mission, eachPass, allPnts_std]
                
                cell_med = allPnts_date[['Grid_ID','ht_egm08']].groupby('Grid_ID').median()
                cell_num = allPnts_date[['Grid_ID','ht_egm08']].groupby('Grid_ID').count()
                cell_std = allPnts_date[['Grid_ID','ht_egm08']].groupby('Grid_ID').std()
                
                df_cell_stats = pd.merge(cell_med,cell_num,left_index=True,right_index=True)
                df_cell_stats.columns = ['ht_med', 'ht_num']
                df_cell_stats['ht_std']=cell_std
                
                #discard the cells with less than 3 pnts or STD>0.1m
                df_cell_stats=df_cell_stats[df_cell_stats['ht_num']>=3]
                df_cell_stats=df_cell_stats[df_cell_stats['ht_std']<0.15]
                
                if not df_cell_stats.shape[0] == 0: 
                    df_cell_stats.reset_index(inplace=True)

                    strDate = eachDate.strftime('%Y%m%d')
                    newCol_shp = 'Ht' + strDate

                    if mission == 'Jason-3':
                        out_grid_JA3_shp = out_grid_JA3_shp.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_JA3_shp.rename(columns={'ht_med':newCol_shp}, inplace=True)

                        newCol_csv = 'JA3_'+strPass+'_'+ strDate  
                        out_grid_JA3_csv = out_grid_JA3_csv.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_JA3_csv.rename(columns={'ht_med':newCol_csv}, inplace=True)
     
                    if mission == 'Sentinel 3A': 
                        out_grid_Sen3A_shp = out_grid_Sen3A_shp.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_Sen3A_shp.rename(columns={'ht_med':newCol_shp}, inplace=True)

                        newCol_csv = 'S3A_'+strPass+'_'+ strDate
                        out_grid_Sen3A_csv = out_grid_Sen3A_csv.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_Sen3A_csv.rename(columns={'ht_med':newCol_csv}, inplace=True)
                    
                    if mission == 'Sentinel 3B': 
                        out_grid_Sen3B_shp = out_grid_Sen3B_shp.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_Sen3B_shp.rename(columns={'ht_med':newCol_shp}, inplace=True)

                        newCol_csv = 'S3B_'+strPass+'_'+ strDate
                        out_grid_Sen3B_csv = out_grid_Sen3B_csv.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_Sen3B_csv.rename(columns={'ht_med':newCol_csv}, inplace=True)
                   
                    if mission == 'Sentinel-6A': 
                        out_grid_Sen6_shp = out_grid_Sen6_shp.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_Sen6_shp.rename(columns={'ht_med':newCol_shp}, inplace=True)

                        newCol_csv = 'S6A_'+strPass+'_'+ strDate
                        out_grid_Sen6_csv = out_grid_Sen6_csv.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_Sen6_csv.rename(columns={'ht_med':newCol_csv}, inplace=True)
                    
                    if mission == 'SWOT':
                        out_grid_SWOT_shp = out_grid_SWOT_shp.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_SWOT_shp.rename(columns={'ht_med':newCol_shp}, inplace=True)

                        newCol_csv = 'STn_'+strPass+'_'+ strDate
                        out_grid_SWOT_n_csv = out_grid_SWOT_n_csv.merge(df_cell_stats[['Grid_ID','ht_med']], on = 'Grid_ID', how = 'left')
                        out_grid_SWOT_n_csv.rename(columns={'ht_med':newCol_csv}, inplace=True)
    
    # out_grid_Sen3A, out_grid_Sen3B, out_grid_Sen6, out_grid_JA3, out_grid_SWOT_n
    if len(out_grid_Sen3A_csv.columns) >1: 
        out_grid_Sen3A_shp.to_file(output_folder+r'\aggre_grid_S3A.shp')
        # out_grid_Sen3A.drop(columns=['geometry'], inplace= True)
        out_grid_Sen3A_csv.to_csv(output_folder+r'\aggre_grid_S3A.csv')
    
    if len(out_grid_Sen3B_csv.columns) >1: 
        out_grid_Sen3B_shp.to_file(output_folder+r'\aggre_grid_S3B.shp')
        # out_grid_Sen3B.drop(columns=['geometry'], inplace= True)
        out_grid_Sen3B_csv.to_csv(output_folder+r'\aggre_grid_S3B.csv')
    
    if len(out_grid_Sen6_csv.columns) >1:
        out_grid_Sen6_shp.to_file(output_folder+r'\aggre_grid_Sen6.shp')
        # out_grid_Sen6.drop(columns=['geometry'], inplace= True)
        out_grid_Sen6_csv.to_csv(output_folder+r'\aggre_grid_Sen6.csv')
    
    if len(out_grid_JA3_csv.columns) >1:
        out_grid_JA3_shp.to_file(output_folder+r'\aggre_grid_JA3.shp')
        # out_grid_JA3.drop(columns=['geometry'], inplace= True)
        out_grid_JA3_csv.to_csv(output_folder+r'\aggre_grid_JA3.csv')
    
    if len(out_grid_SWOT_n_csv.columns) >1:
        out_grid_SWOT_n_shp.to_file(output_folder+r'\aggre_grid_SWOT_n.shp')
        # out_grid_SWOT_n.drop(columns=['geometry'], inplace= True)
        out_grid_SWOT_n_csv.to_csv(output_folder+r'\aggre_grid_SWOT_n.csv')
    # out_allAlti_std.to_csv(output_folder+r'\all_alt_pass_std.csv')
             
    return None

#generate the grid layer for the given polygon
def generate_grid(polygon:gpd.GeoDataFrame, edge_size):
    #get lake extent
    LakeBound=polygon.total_bounds
    # lake_minLon = LakeBound[0]
    # lake_maxLon = LakeBound[2]
    # lake_minLat = LakeBound[1]
    # lake_maxLat = LakeBound[3]

    x_coords = np.arange(LakeBound[0] + edge_size/2, LakeBound[2], edge_size)
    y_coords = np.arange(LakeBound[1] + edge_size/2, LakeBound[3], edge_size)
    combinations = np.array(list(product(x_coords, y_coords)))
    squares = gpd.points_from_xy(combinations[:, 0], combinations[:, 1]).buffer(edge_size / 2, cap_style=3)
    squares_withinLake = squares[squares.within(polygon.loc[0,'geometry'])]
    grid_layer = gpd.GeoDataFrame(geometry=squares_withinLake,crs=polygon.crs)
    grid_layer['Grid_ID'] = grid_layer.index
    
    return grid_layer

def checkIfSSH(swot_raster_path:str):
    is_SSH = False
    
    for file in os.listdir(swot_raster_path):
        if file.endswith('.nc') and 'LR_SSH' in file:
            is_SSH = True
            break
    
    return is_SSH

def resample_SWOT_HR_Raster(SWOT_HR_Raster_dir:str, grid_layer:gpd.GeoDataFrame, lake_shp: gpd.GeoDataFrame, use_median: bool, output_path:str, minHt:float, maxHt:float):
    #get the list of the files and extract the dates from the file name
    # netCDF_files = []    
    #create a dictionary to store the names of the files collected in the same day
    dict_date_files=dict()
    # set_dates = set()
    for file in os.listdir(SWOT_HR_Raster_dir):
        if file.endswith('.nc') and 'SWOT_L2_HR_Raster_' in file:
            # netCDF_files.append(file)
            #the index needs be determined from the file name
            year_str = file[51:55]
            month_str = file[55:57]
            day_str=file[57:59]
            date_collected = (datetime.strptime(year_str+'-'+ month_str +'-'+ day_str, '%Y-%m-%d')).date()
            if date_collected in list(dict_date_files.keys()):
                temp_file_ls = dict_date_files[date_collected] 
                temp_file_ls.append(file)
                dict_date_files[date_collected] = temp_file_ls
            else:
                dict_date_files[date_collected] =[file]
            # set_dates.add(date_collected)
    
    #sort the dates
    date_ls = np.sort(list(dict_date_files.keys()))
     #for each date, first mosaic the tiles, then extract the raster within lake, then use grid layer to do zonal statistics
    # crs_1st = None
    
    out_grid_layer = grid_layer.copy(deep=True)
    # out_df_std = pd.DataFrame(columns = ['date','std'])
    for eachDate in date_ls:
        file_ls = dict_date_files[eachDate]
        # ds_ls = []
        
        grid_zonal_eachDate = pd.DataFrame()
        for eachFile in file_ls:
            ds = xs.open_dataset(os.path.join(SWOT_HR_Raster_dir, eachFile))
            crs_current = CRS.from_cf(ds.crs.attrs)
            
            wse = ds.wse
            load_tide_fes = ds.load_tide_fes
            #to keep consistent, ocean tide correction is excluded for all satellite missions 
            wse_noLoadTide = wse + load_tide_fes

            wse_noLoadTide.coords['x'] = ds['x']
            wse_noLoadTide.coords['y'] = ds['y']

            # Set the CRS information obtained above
            wse_noLoadTide.rio.write_crs(crs_current.to_string(), inplace = True)
            # # wse.rio.write_crs("epsg:4326", inplace = True)
            wse_noLoadTide.rio.set_spatial_dims('x', 'y')
            wse_noLoadTide.rio.write_nodata(np.nan, inplace =True)
            
            try:
                #invert = True, then the part outside polygon will be kept.
                wse_inlake = wse_noLoadTide.rio.clip(lake_shp.geometry.values, lake_shp.crs, drop=True)# invert=False)
            # wse_inlake.rio.to_raster(output_path_name)
            except Exception as e:
                if e.args[0] =='No data found in bounds.': continue
                
            #get the standard deviation of the elevations within lake
            # elev_std = wse_inlake.std().item()
            # if eachDate in out_df_std['date'].values:
            #     if out_df_std.loc[out_df_std['date'] == eachDate, 'std'].values[0] < elev_std: out_df_std.loc[out_df_std['date'] == eachDate, 'std'] = elev_std
            # else: out_df_std.loc[out_df_std.shape[0]] = [eachDate, elev_std]

            #calculate the median elevation for each grid cell
            temp_grid = make_geocube(
                vector_data=grid_layer,
                measurements=['Grid_ID'],
                like= wse_inlake
            )

            temp_grid['elev'] = (wse_inlake.dims, wse_inlake.values, wse_inlake.attrs, wse_inlake.encoding)

            #check if there data within lake
            if np.isnan(temp_grid.elev).sum() == (wse_inlake.shape[0] * wse_inlake.shape[1]): continue
            #check if there is overlap with the grid layer
            if np.isnan(temp_grid.Grid_ID.values).sum() == (wse_inlake.shape[0] * wse_inlake.shape[1]): continue
            
            grouped_elev = temp_grid.drop("spatial_ref").groupby(temp_grid.Grid_ID)
            if use_median: grid_elev_aggregate = grouped_elev.median().rename({'elev':'elev_aggr'})
            else: grid_elev_aggregate = grouped_elev.mean().rename({'elev':'elev_aggr'})
            grid_elev_num = grouped_elev.count().rename({'elev':'elev_num'})
            grid_elev_std = grouped_elev.std().rename({'elev':'elev_std'})

            zonal_stats = xs.merge([grid_elev_aggregate,grid_elev_num,grid_elev_std]).to_dataframe()
            zonal_stats = zonal_stats[~pd.isnull(zonal_stats['elev_aggr'])]
            
            if len(grid_zonal_eachDate) == 0 : grid_zonal_eachDate = zonal_stats
            else: grid_zonal_eachDate = pd.concat([grid_zonal_eachDate, zonal_stats])
            
            # test = 0

        if not grid_zonal_eachDate.empty: 
        
            grid_zonal_eachDate.reset_index(inplace=True)
            grid_no_duplicate = grid_zonal_eachDate.drop_duplicates(subset='Grid_ID',keep=False)
            #find all the duplicates, one grid could be partially coverred by several tiles collected on the same day. The ideal scenario is mosiack the tiles before zonal stats, but the try failed. This is a bypass solution
            grid_duplicated = grid_zonal_eachDate[grid_zonal_eachDate.duplicated(subset='Grid_ID', keep=False)]
            
            if not grid_duplicated.empty:
                #find the grid with the max number of pixels
                group_duplicated = grid_duplicated[['Grid_ID','elev_num']].groupby('Grid_ID').max()
                #select the grid with the max number of pixels
                grid_duplicated_maxPix = grid_duplicated[grid_duplicated['Grid_ID'].isin(group_duplicated.index) & grid_duplicated['elev_num'].isin(group_duplicated['elev_num'])]
                
                grid_zonal_eachDate_clean = pd.concat([grid_no_duplicate, grid_duplicated_maxPix])
            else:
                grid_zonal_eachDate_clean = grid_no_duplicate
            
            #remove the grids with large std and very few pixels
            grid_zonal_eachDate_clean = grid_zonal_eachDate_clean[(grid_zonal_eachDate_clean['elev_num']>3) & (grid_zonal_eachDate_clean['elev_std']<0.15)]

             #remove the grids with elev out of range, if the range has been set
            if minHt < maxHt:
                grid_zonal_eachDate_clean = grid_zonal_eachDate_clean[(grid_zonal_eachDate_clean['elev_aggr']>minHt) & (grid_zonal_eachDate_clean['elev_aggr']<maxHt)]
            
            grid_zonal_eachDate_clean['mad'] = calMADScore(grid_zonal_eachDate_clean['elev_aggr'])
            
            grid_zonal_eachDate_clean = grid_zonal_eachDate_clean[grid_zonal_eachDate_clean['mad']<3]
            
            # #create a new column name in the grid layer for this date
            newcol = 'ST'+ eachDate.strftime('%Y%m%d')
            # if not newcol in out_grid_layer.columns: out_grid_layer[newcol]=np.nan
            #merge the grid results into the grid layer
            out_grid_layer = pd.merge(out_grid_layer,grid_zonal_eachDate_clean[['Grid_ID','elev_aggr']], on='Grid_ID', how='left')
            
            #rename the elev_aggr to newcol
            out_grid_layer.rename(columns={'elev_aggr':newcol},inplace=True)
        
        # test = 0
            
            #region: tried to mosaic the multiple tiles collected in one day. failed. the following codes are depricated.
        #     if crs_1st is None: 
        #         crs_1st = crs_current
        #         ds_ls.append(wse_noLoadTide)#.to_dataset(name='wse'))
        #     else: 
        #         # wse_noLoadTide_wgs84 = wse_noLoadTide.rio.reproject('EPSG:4326')
        #         wse_noLoadTide_reproj = wse_noLoadTide.rio.reproject('EPSG:'+str(crs_1st.to_epsg()))
        #         wse_noLoadTide_reproj_sorted = wse_noLoadTide_reproj.sortby(wse_noLoadTide_reproj.y)
        #         wse_noLoadTide_reproj_sorted.y.attrs['units'] = wse_noLoadTide.y.attrs['units']
        #         ds_ls.append(wse_noLoadTide_reproj_sorted)#.to_dataset(name='wse'))
        #         # test =0
            
        # ds_mosaic = merge_arrays(ds_ls, res=(250,250),crs='EPSG:'+str(crs_1st.to_epsg()), nodata=np.nan) #xs.combine_by_coords(ds_ls, coords='all').to_dataarray()
        # ds_mosaic.coords['x'] = ds_mosaic['x']
        # ds_mosaic.coords['y'] = ds_mosaic['y']
        # ds_mosaic.rio.write_crs(crs_1st.to_string(), inplace = True)
        # ds_mosaic.rio.set_spatial_dims('x', 'y')
        # ds_mosaic.rio.write_nodata(np.nan, inplace =True)
            
        # #extract the pixels inside lake
        # #invert = True, then the part outside polygon will be kept.
        # wse_inlake = ds_mosaic.rio.clip(lake_shp.geometry.values, lake_shp.crs, drop=True)# invert=False)
        # # wse_inlake.rio.to_raster(output_path_name)
        #endregion

        

        # grid_WholeLake = grid_WholeLake.merge(zonal_stats, on = 'Grid_ID', how = 'left')

    # ds = xs.open_dataset(SWOT_HR_Raster_dir, decode_coords="all")
    # Locate CRS info in CF convention in the variable file, convert it to CRS format, and read the string as cc
    # crs_ori = CRS.from_cf(ds.crs.attrs)
    
    out_grid_layer.to_file(os.path.join(output_path,'SWOT_resampled.shp'))
    out_grid_layer.to_csv(os.path.join(output_path,'SWOT_resampled.csv'))
    # out_df_std.to_csv(os.path.join(output_path,'SWOT_HR250m_std.csv'))
    return None

def resample_SWOT_SSH_Raster(SWOT_HR_Raster_dir:str, grid_layer:gpd.GeoDataFrame, lake_shp: gpd.GeoDataFrame, output_path:str, minHt:float, maxHt:float):
    
    netCDF_files = []
    for file in os.listdir(SWOT_HR_Raster_dir):
        if file.endswith('.nc') and 'SWOT_L2_LR_SSH_Expert_' in file:
            netCDF_files.append(file)

    grid_shp_swotHt = grid_layer.copy(deep=True)
    for i in range(len(netCDF_files)):
        file_name = netCDF_files[i]
        input_file = SWOT_HR_Raster_dir + '\\' + file_name
        
        grid_shp_swotHt = parse2Grid(input_file, lake_shp, grid_shp_swotHt, minHt, maxHt)
    
    grid_shp_swotHt.to_file(os.path.join(output_path, 'SWOT_resampled.shp'))
    grid_shp_swotHt.to_csv(os.path.join(output_path, 'SWOT_resampled.csv')) 
     
    return None

#function for removing outliers with MAD
def calMADScore(profile:pd.Series):
    #replace the nan value with a super low value, so that it will be filtered out later
    profile = profile.replace(np.nan, -10000.0)
    median= np.median(profile)
    #1.4826 is a correction term that makes the MAD equal to the standard deviation of a normal distribution
    MAD = 1.4826 * stats.median_abs_deviation(profile)
        
    #calculate the absolute MAD score
    MAD_score = np.abs((profile - median)/MAD)
     
    return MAD_score

#this function is for parse SWOT Low Resolution SSH data
def parse2Grid(inputFile_pathName: str, lake_shp: gpd.GeoDataFrame, grid_shp: gpd.GeoDataFrame, minHt:float, maxHt:float):
    # region: using geopandas 
    ds = netCDF4.Dataset(inputFile_pathName)
        
    # total_bounds returns a tuple containing minx, miny, maxx, maxy
    # bounds returns a DataFrame with columns minx, miny, maxx, maxy
    # LakeBound=lake_shp.total_bounds
    # minLon = LakeBound[0]
    # maxLon = LakeBound[2]
    # minlat = LakeBound[1]
    # maxlat = LakeBound[3]

    longitude = ds.variables['longitude'][:]
    latitude = ds.variables['latitude'][:]
    #ssh_karin_2: dry, wet, iono, sea state biases are included, the others are not included
    ssh_karin2 = ds.variables['ssh_karin_2'][:]

    solid_earth_tide = ds.variables['solid_earth_tide'][:]
    pole_tide = ds.variables['pole_tide'][:]
    ht_cor_xover = ds.variables['height_cor_xover'][:]
    #egm2008 is referenced to mean tide system
    geoid_egm08 = ds.variables['geoid'][:]

    #ssh fill value
    # fill_value = ds.variables['ssh_karin']._FillValue

    # Flatten the 2D arrays
    lon_flat = longitude.flatten()
    lat_flat = latitude.flatten()
    ssh_flat = ssh_karin2.flatten()
    solid_earth_flat = solid_earth_tide.flatten()
    pole_flat = pole_tide.flatten()
    ht_xover_flat = ht_cor_xover.flatten()
    geoid_egm08_flat = geoid_egm08.flatten()

    # Check for NaN values in the values array
    # nan_mask  = np.isnan(ssh_flat)

    # Filter out NaN values: too slow
    # latitudes_filtered = [lat for i, lat in enumerate(lat_flat) if nan_mask[i] == False]
    # longitudes_filtered = [lon for i, lon in enumerate(lon_flat) if nan_mask[i] == False]
    # ssh_filtered = [ssh_value for i, ssh_value in enumerate(ssh_flat) if nan_mask[i] == False]
    # geoid_filtered = [geoid_value for i, geoid_value in enumerate(geoid_egm08_flat) if nan_mask[i] == False]

    matrix_img = pd.DataFrame()
    matrix_img['lat'] =  lat_flat
    matrix_img['lon'] = lon_flat
    matrix_img['ssh_kar2']=ssh_flat
    matrix_img['solid_ear']=solid_earth_flat
    matrix_img['pole_tid'] = pole_flat
    matrix_img['ht_cor_xov'] = ht_xover_flat
    matrix_img['geoid_08'] = geoid_egm08_flat

    # Filter out NaN values
    matrix_filtered = ((matrix_img[(matrix_img['ssh_kar2'].notna())&(matrix_img['geoid_08'].notna())&(matrix_img['ht_cor_xov'].notna())&(matrix_img['pole_tid'].notna()&(matrix_img['solid_ear'].notna()))]).copy()).reset_index(drop=True)
    # the corrections of air pressure and ocean tide are not included.
    matrix_filtered['ssh_egm08'] = matrix_filtered['ssh_kar2'] + matrix_filtered['ht_cor_xov'] - matrix_filtered['solid_ear'] - matrix_filtered['pole_tid'] - matrix_filtered['geoid_08']
    # filter out elev out of min-max range, if the range has been set
    if minHt < maxHt:
        matrix_filtered = matrix_filtered[(matrix_filtered['ssh_egm08']>minHt) & (matrix_filtered['ssh_egm08']< maxHt)].reset_index(drop=True)

    # convert longitude from (0-360) to (-180 to 180)
    matrix_filtered['lon'] = (matrix_filtered['lon'] +180)%360-180
    # matrix_lakeBound = matrix_filtered[(matrix_filtered['longitude']>minLon)&(matrix_filtered['longitude']<maxLon)&(matrix_filtered['latitude']>minlat)&(matrix_filtered['latitude']<maxlat)].copy().reset_index(drop=True)

    gdf_matrix = gpd.GeoDataFrame(matrix_filtered, geometry=gpd.points_from_xy(matrix_filtered['lon'],matrix_filtered['lat']), crs='epsg:4326')
    pixel_InLake = gpd.clip(gdf_matrix, lake_shp)
    if pixel_InLake.empty: return grid_shp
    else:
        pixel_InLake_reproj = pixel_InLake.to_crs(grid_shp.crs)

        # pixel_InLake_reproj.to_file(output_path_name, driver='ESRI Shapefile')

        #spatial join the pixels to grids.
        grid_sjoin_pixel = gpd.sjoin_nearest(grid_shp, pixel_InLake_reproj, how = 'left', max_distance= 2000)

        #groupby('ID') to estimate the median ht within each grid.
        df_sub = (grid_sjoin_pixel[['Grid_ID','ssh_egm08']]).groupby('Grid_ID').median()
        
        grid_shp = pd.merge_asof(grid_shp.sort_values(by = 'Grid_ID', ascending = True), df_sub.sort_values(by = 'Grid_ID', ascending = True), left_on='Grid_ID', right_on='Grid_ID')
        sensing_date_str = ds.equator_time[0:4]+ds.equator_time[5:7]+ds.equator_time[8:10]
        grid_shp.rename(columns = {'ssh_egm08':'ST'+sensing_date_str}, inplace= True)
        
        # #after groupby, the geodataframe loses its crs info. This is a bug. need to reset the crs
        # grid_sjoin_pixel_2 = (grid_sjoin_pixel.groupby('ID').median()).set_crs(grid_shp.crs)
        # # grid_sjoin_pixel_2.to_file(r"D:\GoogleDrive_AppState\FundedProjects\USAID_NASA_2023_2026\PyTools\LakeShp\Grid_sjoin_pixels.shp")
        #drop the other columns and keep only the 'ssh_egm08', then rename it to the date of data collection
    # grid_sjoin_pixel_2.drop(['lat','lon','ssh_kar2','solid_ear','pole_tid','ht_cor_xov','geoid_08'], axis = 1)
    
    return grid_shp


