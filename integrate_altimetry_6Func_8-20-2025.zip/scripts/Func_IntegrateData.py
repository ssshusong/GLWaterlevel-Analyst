import os
import pandas as pd
from datetime import datetime
import numpy as np
import matplotlib.pyplot as plt


def integrate_alt_SWOT_noEOF(resampled_SWOT_path:str, aggre_alt_path:str, output_path_water:str, output_path_bias:str, bias_passBased:bool, display_water_levels:bool):
    #get the path of the parsed profile altimetry data from the temp_path.txt under the aggre_alt_path
    parsed_profile_altimetry_path = ''
    with open(aggre_alt_path + r'\temp_path.txt', 'r') as file:
        parsed_profile_altimetry_path = file.readline().strip()
    
     #read in the parsed altimetry csv files
    all_alt_points = pd.DataFrame()
    for file in os.listdir(parsed_profile_altimetry_path):
        if file.endswith('.csv') and 'Altimetry' in file:
            temp_df = pd.read_csv(os.path.join(parsed_profile_altimetry_path,file), index_col=0)
            if all_alt_points.empty: all_alt_points = temp_df
            else: all_alt_points = pd.concat([all_alt_points, temp_df],ignore_index=True)      
    
    all_alt_points.reset_index(drop=True,inplace=True)
    all_alt_points['date'] = (pd.to_datetime(all_alt_points['date'],format='%Y-%m-%d')).apply(lambda x:x.date())
    
    #first check if the file exists
    exist_s3a_csv = os.path.exists(aggre_alt_path+r'\aggre_grid_S3A.csv')
    if exist_s3a_csv: grid_Sen3A = pd.read_csv(aggre_alt_path+r'\aggre_grid_S3A.csv', index_col=0)

    exist_s3b_csv = os.path.exists(aggre_alt_path+r'\aggre_grid_S3B.csv')
    if exist_s3b_csv: grid_Sen3B = pd.read_csv(aggre_alt_path+r'\aggre_grid_S3B.csv', index_col=0)

    exist_s6a_csv = os.path.exists(aggre_alt_path+r'\aggre_grid_Sen6.csv')
    if exist_s6a_csv: grid_Sen6 = pd.read_csv(aggre_alt_path+r'\aggre_grid_Sen6.csv', index_col=0)

    exist_ja3_csv = os.path.exists(aggre_alt_path+r'\aggre_grid_JA3.csv')
    if exist_ja3_csv: grid_JA3 = pd.read_csv(aggre_alt_path+r'\aggre_grid_JA3.csv', index_col=0)

    exist_STn_csv = os.path.exists(aggre_alt_path+r'\aggre_grid_SWOT_n.csv')
    if exist_STn_csv: grid_SWOT_n = pd.read_csv(aggre_alt_path+r'\aggre_grid_SWOT_n.csv', index_col=0)

    exist_STs_csv = os.path.exists(aggre_alt_path+r'\SWOT_resampled.csv')
    if exist_STs_csv: resampledSWOT_grid = pd.read_csv(resampled_SWOT_path+r'\SWOT_resampled.csv', index_col=0)
    else: return 'SWOT swath data missing!'
    
    if exist_s3a_csv: cell_pairs_swot_sen3a, biases_swot_sen3a= estimate_Bias(resampledSWOT_grid,grid_Sen3A)
    if exist_s3b_csv: cell_pairs_swot_sen3b, biases_swot_sen3b= estimate_Bias(resampledSWOT_grid,grid_Sen3B)
    if exist_s6a_csv: cell_pairs_swot_sen6, biases_swot_sen6= estimate_Bias(resampledSWOT_grid,grid_Sen6)
    if exist_ja3_csv: cell_pairs_swot_JA3, biases_swot_JA3= estimate_Bias(resampledSWOT_grid,grid_JA3)
    if exist_STn_csv: cell_pairs_swot_SWOT_n, biases_swot_SWOT_n= estimate_Bias(resampledSWOT_grid,grid_SWOT_n)
    
    all_cell_pairs = pd.DataFrame()
    all_biases = pd.DataFrame()
    
    if exist_s3a_csv:
        if not cell_pairs_swot_sen3a.empty: all_cell_pairs = cell_pairs_swot_sen3a
    
    if exist_s3b_csv:
        if not cell_pairs_swot_sen3b.empty:
            if not all_cell_pairs.empty: all_cell_pairs = pd.concat([cell_pairs_swot_sen3b,all_cell_pairs], ignore_index= True)
            else: all_cell_pairs = cell_pairs_swot_sen3b
    
    if exist_s6a_csv:
        if not cell_pairs_swot_sen6.empty:
            if not all_cell_pairs.empty: all_cell_pairs = pd.concat([cell_pairs_swot_sen6,all_cell_pairs], ignore_index= True)
            else: all_cell_pairs = cell_pairs_swot_sen3b
        
   
    if exist_ja3_csv:
        if not cell_pairs_swot_JA3.empty:
            if not all_cell_pairs.empty: all_cell_pairs = pd.concat([cell_pairs_swot_JA3,all_cell_pairs], ignore_index= True)
            else: all_cell_pairs = cell_pairs_swot_sen3b
    
    if exist_STn_csv:
        if not cell_pairs_swot_SWOT_n.empty:
            if not all_cell_pairs.empty: all_cell_pairs = pd.concat([cell_pairs_swot_SWOT_n,all_cell_pairs], ignore_index= True)
            else: all_cell_pairs = cell_pairs_swot_sen3b
        

    water_levels_SWOT_s = generate_water_level_series_swot_s(resampledSWOT_grid)
    all_water_levels = water_levels_SWOT_s
    
    if exist_s3b_csv:
        if not biases_swot_sen3a.empty:
            water_levels_sen3a = generate_water_level_series(grid_Sen3A, biases_swot_sen3a,bias_passBased)
            all_water_levels = pd.concat([all_water_levels,water_levels_sen3a],ignore_index= True)
            
            all_biases = biases_swot_sen3a
        else:
            #if there is no bias between profiling altimetry mission and swot, calculate the median of each overpass, and use it as the original water level
            #get the point data for Sen3a
            df_alt_Sen3a = all_alt_points[all_alt_points['mission']=='Sentinel 3A']
            
            #get the median of the elevation    
            water_levels_sen3a = df_alt_Sen3a[['date','pass','ht_egm08']].groupby('date').median()
            water_levels_sen3a.reset_index(inplace=True)
            water_levels_sen3a.insert(2,'waterLevels_cal',np.nan)
            water_levels_sen3a['mission'] = 'S3A'
            water_levels_sen3a.rename(columns={'ht_egm08':'waterLevels_ori'}, inplace=True)
            
            all_water_levels = pd.concat([all_water_levels,water_levels_sen3a],ignore_index= True)   
    
    if exist_s3b_csv:
        if not biases_swot_sen3b.empty:
            water_levels_sen3b = generate_water_level_series(grid_Sen3B, biases_swot_sen3b,bias_passBased)
            all_water_levels = pd.concat([all_water_levels,water_levels_sen3b],ignore_index= True)
            
            all_biases = pd.concat([all_biases, biases_swot_sen3b], ignore_index= True)
        else:
            #if there is no bias between profiling altimetry mission and swot, calculate the median of each overpass, and use it as the original water level
            #get the point data for Sen3B
            df_alt_Sen3b = all_alt_points[all_alt_points['mission']=='Sentinel 3B']
            
            #get the median of the elevation    
            water_levels_sen3b = df_alt_Sen3b[['date','pass','ht_egm08']].groupby('date').median()
            water_levels_sen3b.reset_index(inplace=True)
            water_levels_sen3b.insert(2,'waterLevels_cal',np.nan)
            water_levels_sen3b['mission'] = 'S3B'
            water_levels_sen3b.rename(columns={'ht_egm08':'waterLevels_ori'}, inplace=True)
            
            all_water_levels = pd.concat([all_water_levels,water_levels_sen3b],ignore_index= True) 
    
    if exist_s6a_csv:
        if not biases_swot_sen6.empty:
            water_levels_sen6 = generate_water_level_series(grid_Sen6, biases_swot_sen6,bias_passBased)
            all_water_levels = pd.concat([all_water_levels,water_levels_sen6],ignore_index= True)
            
            all_biases = pd.concat([all_biases, biases_swot_sen6], ignore_index= True)
        else:
            #if there is no bias between profiling altimetry mission and swot, calculate the median of each overpass, and use it as the original water level
            #get the point data for Sen6
            df_alt_Sen6 = all_alt_points[all_alt_points['mission']=='Sentinel-6A']
            
            #get the median of the elevation    
            water_levels_sen6a = df_alt_Sen6[['date','pass','ht_egm08']].groupby('date').median()
            water_levels_sen6a.reset_index(inplace=True)
            water_levels_sen6a.insert(2,'waterLevels_cal',np.nan)
            water_levels_sen6a['mission'] = 'S6A'
            water_levels_sen6a.rename(columns={'ht_egm08':'waterLevels_ori'}, inplace=True)
            
            all_water_levels = pd.concat([all_water_levels,water_levels_sen6a],ignore_index= True)
    
    if exist_ja3_csv:
        if not biases_swot_JA3.empty:
            water_levels_JA3 = generate_water_level_series(grid_JA3, biases_swot_JA3,bias_passBased)
            all_water_levels = pd.concat([all_water_levels,water_levels_JA3],ignore_index= True)
            
            all_biases = pd.concat([all_biases, biases_swot_JA3], ignore_index= True)
        else:
            #if there is no bias between profiling altimetry mission and swot, calculate the median of each overpass, and use it as the original water level
            #get the point data for Jason-3
            df_alt_JA3 = all_alt_points[all_alt_points['mission']=='Jason-3']
            
            #get the median of the elevation    
            water_levels_ja3 = df_alt_JA3[['date','pass','ht_egm08']].groupby('date').median()
            water_levels_ja3.reset_index(inplace=True)
            water_levels_ja3.insert(2,'waterLevels_cal',np.nan)
            water_levels_ja3['mission'] = 'JA3'
            water_levels_ja3.rename(columns={'ht_egm08':'waterLevels_ori'}, inplace=True)
            
            all_water_levels = pd.concat([all_water_levels,water_levels_ja3],ignore_index= True)

    if exist_STn_csv:     
        if not biases_swot_SWOT_n.empty:
            water_levels_SWOT_n = generate_water_level_series(grid_SWOT_n, biases_swot_SWOT_n,bias_passBased)
            all_water_levels = pd.concat([all_water_levels,water_levels_SWOT_n],ignore_index= True)

            all_biases = pd.concat([all_biases, biases_swot_SWOT_n], ignore_index= True)
        else:
            #if there is no bias between profiling altimetry mission and swot, calculate the median of each overpass, and use it as the original water level
            #get the point data for SWOT nadir
            df_alt_SWOTn = all_alt_points[all_alt_points['mission']=='SWOT']
            
            #get the median of the elevation    
            water_levels_SWOTn = df_alt_SWOTn[['date','pass','ht_egm08']].groupby('date').median()
            water_levels_SWOTn.reset_index(inplace=True)
            water_levels_SWOTn.insert(2,'waterLevels_cal',np.nan)
            water_levels_SWOTn['mission'] = 'STn'
            water_levels_SWOTn.rename(columns={'ht_egm08':'waterLevels_ori'}, inplace=True)
            
            all_water_levels = pd.concat([all_water_levels,water_levels_SWOTn],ignore_index= True)
    
    if not all_cell_pairs.empty: all_cell_pairs.to_csv(os.path.join(output_path_bias, 'alt_swot_cell_pairs.csv'), index=False)
    if not all_biases.empty: 
        all_biases[['bias_pass','bias_mission']] = all_biases[['bias_pass','bias_mission']].astype(float)
        all_biases.to_csv(os.path.join(output_path_bias, 'alt_swot_biases.csv'), index=False)
    
    all_water_levels[['waterLevels_ori','waterLevels_cal']] = all_water_levels[['waterLevels_ori','waterLevels_cal']].astype(float)
    all_water_levels.to_csv(os.path.join(output_path_water, 'alt_swot_integrated_waterLevels.csv'), index=False)

    if display_water_levels: displayTimeSeries(all_water_levels)

    return None

def estimate_Bias(swot_grid:pd.DataFrame, alt_grid:pd.DataFrame):
    all_cell_pairs = pd.DataFrame()
    biases = pd.DataFrame()
    
    if alt_grid.columns.shape[0] >1:
        #get the list of SWOT dates
        swot_col = swot_grid.columns
        date_ls_swot =[]
        dict_date_colName_swot = dict()
        for item in swot_col[0:len(swot_col)]:
            date_str = item[2:6]+'-'+item[6:8]+'-'+item[8:]
            try:
                date_temp = datetime.strptime(date_str,'%Y-%m-%d').date()
            except Exception as e:
                continue
            date_ls_swot.append(date_temp)
            dict_date_colName_swot[date_temp] = item
        
        df_swot = pd.DataFrame(index= date_ls_swot)
        df_swot['date']=date_ls_swot
        
        #get the list of alt dates
        alt_col = alt_grid.columns
        alt_str = ''
        date_ls_alt =[]
        dict_date_pass = dict()
        dict_date_colName_alt = dict()
        for item in alt_col[0:len(alt_col)]:
            
            date_str = item[8:12]+'-'+item[12:14]+'-'+item[14:]
            try:
                date_temp = datetime.strptime(date_str,'%Y-%m-%d').date()
            except Exception as e:
                continue    
            
            if not alt_str: alt_str = item[0:3]
            date_ls_alt.append(date_temp)
            dict_date_colName_alt[date_temp] = item
            dict_date_pass[date_temp] = int(item[4:7])
            
        df_alt = pd.DataFrame(index= date_ls_alt)
        df_alt['date']=date_ls_alt
        
        #find out the overlapping dates
        
        overlap_dates = pd.merge(df_swot,df_alt, left_index=True, right_index=True).copy(deep=True)
        if overlap_dates.empty: return all_cell_pairs, biases
        else:
            ls_overlap_dates = np.sort(overlap_dates.index.to_list())
            
            #find the co-located grid cells
            for eachDate in ls_overlap_dates:
                swot_col_name = dict_date_colName_swot[eachDate]
                alt_col_name = dict_date_colName_alt[eachDate]
                alt_passNum = dict_date_pass[eachDate]
                
                swot_grid_thisDate = swot_grid[['Grid_ID', swot_col_name]]
                alt_grid_thisDate = alt_grid[['Grid_ID', alt_col_name]]
                
                swot_grid_thisDate_noNA = swot_grid_thisDate[~np.isnan(swot_grid_thisDate[swot_col_name])]
                swot_grid_thisDate_noNA.set_index('Grid_ID', inplace = True)
                alt_grid_thisDate_noNA = alt_grid_thisDate[~np.isnan(alt_grid_thisDate[alt_col_name])]
                alt_grid_thisDate_noNA.set_index('Grid_ID', inplace = True)
                
                overlap_grids = pd.merge(swot_grid_thisDate_noNA,alt_grid_thisDate_noNA,left_index=True, right_index=True)
                
                if overlap_grids.empty: continue
                overlap_grids['date'] = eachDate
                overlap_grids['pass'] = alt_passNum
                overlap_grids.reset_index(inplace= True)
                overlap_grids.rename(columns={swot_col_name:'swot_swath',alt_col_name:'Alt_ht'}, inplace= True)
                if all_cell_pairs.empty: all_cell_pairs = overlap_grids
                else: all_cell_pairs = pd.concat([all_cell_pairs,overlap_grids])
        
        if not all_cell_pairs.empty: 
            all_cell_pairs['mission'] = alt_str
            #estimate the bias for each pass
            #get the unique pass list
            ls_passNum = all_cell_pairs['pass'].unique().tolist()
            for eachPass in ls_passNum:
                #find all the grid pairs 
                grid_pass =  all_cell_pairs[all_cell_pairs['pass'] == eachPass]
                #Alt - SWOT
                diff= grid_pass['Alt_ht'] - grid_pass['swot_swath']
                bias = diff.median()
                grid_num = diff.shape[0]
                pass_bias = pd.DataFrame(columns=['bias_pass','pass','gridNum'])
                pass_bias.loc[len(pass_bias.index)] = [bias,eachPass,grid_num] 

                if biases.empty: biases = pass_bias
                else: biases = pd.concat([biases,pass_bias])
        
            diff_all = all_cell_pairs['Alt_ht'] - all_cell_pairs['swot_swath']
            bias_mission = diff_all.median()
            biases['mission'] = alt_str
            biases['bias_mission'] = bias_mission
            
            all_cell_pairs.reset_index(drop=True,inplace= True)
        
    return all_cell_pairs, biases

def generate_water_level_series(aggregated_grid_data:pd.DataFrame, biases: pd.DataFrame, pass_based:bool):
    #get the list of alt dates
    alt_col = aggregated_grid_data.columns
    alt_str = ''
    # date_ls_alt =[]
    df_date_colName_waterLevel = pd.DataFrame(columns=['colName','date','pass'])
    for item in alt_col[0:len(alt_col)]:
        date_str = item[8:12]+'-'+item[12:14]+'-'+item[14:]
        try: 
            date_temp = datetime.strptime(date_str,'%Y-%m-%d').date()
        except Exception as e:
            continue
        # date_ls_alt.append(date_temp)
        if not alt_str: alt_str = item[0:3]
        df_date_colName_waterLevel.loc[len(df_date_colName_waterLevel.index)] = [item, date_temp, int(item[4:7])] 
        
    # water_level_series = pd.DataFrame(index= date_ls_alt)
    # water_level_series['date']=date_ls_alt
    
    #calculate water level using median 
    aggregated_grid_data.drop('Grid_ID', axis= 1, inplace= True)
    aggregated_grid_data.reset_index(drop = True,inplace=True)
    water_levels = aggregated_grid_data.median(skipna=True)
    STDs = aggregated_grid_data.std(skipna=True)
    df_date_colName_waterLevel.set_index('colName',inplace=True)
    df_date_colName_waterLevel.loc[water_levels.index,'waterLevels_ori'] = water_levels

    # water_levels_series = df_date_colName.reset_index(inplace=True,drop=True)
    
    if pass_based:
        pass_ls = df_date_colName_waterLevel['pass'].unique()        
        for eachPass in pass_ls:
            waterLevels_thisPass = df_date_colName_waterLevel[df_date_colName_waterLevel['pass']==eachPass]['waterLevels_ori']
            
            #get the bias of this pass
            try:
                bias_thisPass = biases[(biases['mission']==alt_str) & (biases['pass']==eachPass)]['bias_pass'].values[0]
            except Exception as e:
                bias_thisPass = np.nan
            
            if np.isnan(bias_thisPass):
                #no bias for this pass, use the bias based on whole mission
                bias_mission = biases[biases['mission']==alt_str]['bias_mission'].values[0]
                waterLevels_thisPass_cali = waterLevels_thisPass-bias_mission
            else: waterLevels_thisPass_cali = waterLevels_thisPass-bias_thisPass
            
            df_date_colName_waterLevel.loc[waterLevels_thisPass_cali.index,'waterLevels_cal'] = waterLevels_thisPass_cali
    
    else:
        bias_mission = biases[biases['mission']==alt_str]['bias_mission'].values[0]
        df_date_colName_waterLevel['waterLevels_cal'] = df_date_colName_waterLevel['waterLevels_ori']-bias_mission
    
    df_date_colName_waterLevel.loc[STDs.index,'STD'] = STDs
    df_date_colName_waterLevel['mission'] = alt_str
    df_date_colName_waterLevel.reset_index(drop= True,inplace=True)
    return df_date_colName_waterLevel

def generate_water_level_series_swot_s(aggregated_grid_data:pd.DataFrame):
    water_level_series = pd.DataFrame()
    
    #get the list of SWOT dates
    swot_col = aggregated_grid_data.columns
    # alt_str = alt_col[2][0:3]
    # date_ls_swot =[]
    df_date_colName_waterLevel = pd.DataFrame(columns=['colName','date','pass'])
    for item in swot_col[0:len(swot_col)]:
        date_str = item[2:6]+'-'+item[6:8]+'-'+item[8:]
        try:
            date_temp = datetime.strptime(date_str,'%Y-%m-%d').date()
        except Exception as e:
            continue
        # date_ls_swot.append(date_temp)
        df_date_colName_waterLevel.loc[len(df_date_colName_waterLevel.index)] = [item, date_temp, np.nan] 
        
    #calculate water level using median 
    aggregated_grid_data.drop(['Grid_ID','geometry'], axis= 1, inplace= True)
    aggregated_grid_data.reset_index(drop = True,inplace=True)
    water_levels = aggregated_grid_data.median(skipna=True)
    STDs = aggregated_grid_data.std(skipna=True)
    df_date_colName_waterLevel.set_index('colName',inplace=True)
    df_date_colName_waterLevel.loc[water_levels.index,'waterLevels_cal'] = water_levels
    df_date_colName_waterLevel['waterLevels_ori'] = water_levels
    df_date_colName_waterLevel['STD'] = STDs
    df_date_colName_waterLevel['mission'] = 'STs'
    df_date_colName_waterLevel.reset_index(drop= True,inplace=True)   
    
    return df_date_colName_waterLevel

def displayTimeSeries(df:pd.DataFrame):   
    """
    Two-row subplot:
    - Top: 'waterLevels_ori' vs 'date' scatter points by mission (alternating filled/hollow).
    - Bottom: 'waterLevels_cal' vs 'date' as line + hollow points.
    Rows with missing values in 'waterLevels_cal' or 'waterLevels_ori' are removed.
    Styling:
    - Times New Roman font
    - Gray backgrounds and visible spines
    - Top subplot legend inside the axes (canvas), bottom left with distinct background
    - Legend backgrounds slightly lighter than axes background for contrast
    """
    # Remove rows with missing waterLevels_cal or waterLevels_ori
    df_clean = df.dropna(subset=['waterLevels_cal', 'waterLevels_ori']).copy()

    df_clean['date'] = pd.to_datetime(df_clean['date'])
    df_clean = df_clean.sort_values('date')

    missions = df_clean['mission'].unique()
    markers = ['o', 's', '^', 'D', 'P', '*', 'X', 'v']
    colors = plt.cm.tab10.colors  # 10 distinct colors

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 6), sharex=True,
                                   gridspec_kw={'height_ratios': [1, 1]})
    fig.patch.set_facecolor('white')

    for ax in [ax1, ax2]:
        ax.set_facecolor('#e0e0e0')
        for spine in ['top', 'right', 'bottom', 'left']:
            ax.spines[spine].set_visible(True)
            ax.spines[spine].set_color('#666666')
        ax.tick_params(axis='both', labelsize=11)
        for label in (ax.get_xticklabels() + ax.get_yticklabels()):
            label.set_fontname('Times New Roman')

    # Top subplot: mixed filled and hollow markers
    for i, mission in enumerate(missions):
        subset = df_clean[df_clean['mission'] == mission]
        if i % 2 == 0:
            # Even index: filled markers
            ax1.scatter(subset['date'], subset['waterLevels_ori'],
                        label=f'Mission: {mission}',
                        marker=markers[i % len(markers)],
                        facecolor=colors[i % len(colors)],
                        edgecolor='black',
                        linewidth=0.7,
                        s=25,
                        alpha=0.9,
                        zorder=3)
        else:
            # Odd index: hollow markers
            ax1.scatter(subset['date'], subset['waterLevels_ori'],
                        label=f'Mission: {mission}',
                        marker=markers[i % len(markers)],
                        facecolor='none',
                        edgecolor=colors[i % len(colors)],
                        linewidth=1.2,
                        s=25,
                        alpha=0.9,
                        zorder=3)

    ax1.set_title('Original Water Levels by Mission', fontsize=14, fontweight='bold', fontname='Times New Roman')
    ax1.set_ylabel('Water Level (Original)', fontsize=12, fontweight='bold', fontname='Times New Roman')

    leg = ax1.legend(fontsize=10, frameon=True, loc='best',
                     ncol=2, handletextpad=0.5)
    leg.get_frame().set_facecolor('#f5f5f5')  # lighter than canvas background
    leg.get_frame().set_edgecolor('#666666')

    for text in leg.get_texts():
        text.set_fontname('Times New Roman')
    leg.set_title(None)  # No title for legend

    # Bottom subplot: line + hollow points with smaller points
    points = ax2.scatter(df_clean['date'], df_clean['waterLevels_cal'],
                        label='Harmonized Water Levels (Points)',
                        facecolor='none',
                        edgecolor='#20b2aa',
                        linewidth=1.2,
                        s=10,
                        zorder=2)

    # line, = ax2.plot(df_clean['date'], df_clean['waterLevels_cal'],
    #                 label='Harmonized Water Levels (Line)',
    #                 color='#6a0dad', linewidth=1, zorder=1)

    ax2.set_title('Harmonized Water Levels', fontsize=14, fontweight='bold', fontname='Times New Roman')
    ax2.set_xlabel('Date', fontsize=12, fontweight='bold', fontname='Times New Roman')
    ax2.set_ylabel('Water Level (Calibrated)', fontsize=12, fontweight='bold', fontname='Times New Roman')

    legend = ax2.legend(handles=[points])
    legend.get_frame().set_facecolor('#f5f5f5')  # lighter than canvas background
    legend.get_frame().set_edgecolor('#666666')
    for text in legend.get_texts():
        # text.set_fontweight('bold')
        text.set_fontname('Times New Roman')

    plt.tight_layout(h_pad=2)
    plt.show()

    return None
     