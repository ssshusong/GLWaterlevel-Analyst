from qgis.PyQt.QtWidgets import QMessageBox, QProgressBar, QInputDialog, QLineEdit
import os
from subprocess import Popen, PIPE
import sys,os
# from osgeo import gdal

def create_message(title,message):
        msg = QMessageBox()
        msg.setWindowTitle(f'{title}')
        msg.setText(f'{message}')
        msg.addButton(QMessageBox.Yes)
        msg.addButton(QMessageBox.No)
        ret = msg.exec_()
        return ret