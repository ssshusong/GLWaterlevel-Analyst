import netCDF4
import os
import pandas as pd
import geopandas as gpd
import numpy as np
from scipy import stats
from datetime import datetime, timezone


#function to parse the profiling altimetry data (QGIS Plugin)
def parseProfileAltimetry(original_Data_folder, lake_shp_path, buff_dist, MAD_thre, max_ht, min_ht, save_csv, save_shp, output_dir):
    #save the min and max elevation to a temporay txt. This will be used in the 3th step to filter SWOT data.
    with open(output_dir + r'\temp_elevRange.txt', 'w') as file:
        file.write(str(min_ht) + ',' + str(max_ht))

    #read the lake shapefile as geodata frame
    lake_shp = gpd.read_file(lake_shp_path, drivers = 'shapefile')    
    #convert from wgs84 to UTM projected crs
    lake_shp_reproj = lake_shp.to_crs(lake_shp.estimate_utm_crs())
    #lake_shp_reproj.crs.axis_info[0].unit_name
    #perform an inward buffer, the buff_dist is in km, while the utm crs is in meter
    if buff_dist > 0: lake_shp_inwardBuff = lake_shp_reproj.buffer(-(buff_dist * 1000))
    else: return None
    
    #this will be used to clip points within lake. Need to make sure the crs is the same with the point shapefile wgs84
    lake_shp_inwardBuff = lake_shp_inwardBuff.to_crs('epsg:4326')
    
    netCDF_files = []
    for file in os.listdir(original_Data_folder):
        if file.endswith('.nc'):
            netCDF_files.append(file)
    
    #all footprints
    out_df_allPoints = pd.DataFrame()
    index_allPointsFile = 0
    #only the time series after filtering
    out_timeSeries = pd.DataFrame()
    
    for i in range(len(netCDF_files)):
        file_name = netCDF_files[i]
        if 'SWOT_L2_HR_Raster_' in file_name: continue
        
        input_file = original_Data_folder + '\\' + file_name
        
        #identify satellite mission 
        # missionName = netCDF4.Dataset(input_file).mission_name
        if 'JA3_GPN_' in file_name:
            temp_df_points = extractJason3(input_file, lake_shp_inwardBuff)
        elif ('S3A_SR_2_LAN_HY_' in file_name or 'S3B_SR_2_LAN_HY_' in file_name):
            temp_df_points = extractSen3(input_file, lake_shp_inwardBuff)
        elif 'S6A_P4_2__HR_STD__NT_' in file_name :    
            temp_df_points = extractSen6(input_file, lake_shp_inwardBuff)
        elif 'SWOT_GPN_' in file_name:
            temp_df_points = extractSWOT(input_file, lake_shp_inwardBuff)
        
        if (min_ht == 0.0 and max_ht == 0.0) or (min_ht == max_ht):
            temp_df_points = temp_df_points[temp_df_points['MAD_score']<MAD_thre]
        else:
            temp_df_points = temp_df_points[(temp_df_points['ht_egm08']>min_ht) & (temp_df_points['ht_egm08']<max_ht) & (temp_df_points['MAD_score']<MAD_thre)]
        
        if len(temp_df_points) ==0:
            continue
        else:
            # temp_df_timeSeries = calWaterLevel(temp_df_points)
            out_df_allPoints = pd.concat([out_df_allPoints, temp_df_points], ignore_index=True)
        
        # if len(temp_df_timeSeries) == 0:
        #     continue
        # else:
        #     out_timeSeries = pd.concat([out_timeSeries, temp_df_timeSeries], ignore_index= True)
        
        
        #save all footprints to a CSV when the number of footprints exceeds 30000
        if len(out_df_allPoints) >= 30000:
            if save_csv:
                out_df_allPoints.to_csv(output_dir + "\Altimetry_Footprints_" + str(index_allPointsFile)+".csv")
            if save_shp:
                out_gdf = gpd.GeoDataFrame(out_df_allPoints, geometry=gpd.points_from_xy(out_df_allPoints['longitude'],out_df_allPoints['latitude']), crs='epsg:4326')
                out_gdf.to_file(output_dir + "\Altimetry_Footprints_" + str(index_allPointsFile)+".shp")
            
            out_df_allPoints = pd.DataFrame(None)
            index_allPointsFile = index_allPointsFile +1 
        
        # out_df_allPoints.to_csv(r"D:\GoogleDrive_AppState\FundedProjects\USAID_NASA_2023_2026\PyTools\test2.csv")
    if save_csv:
        out_df_allPoints.to_csv(output_dir + "\Altimetry_Footprints_" + str(index_allPointsFile)+".csv")
    if save_shp:
        out_gdf = gpd.GeoDataFrame(out_df_allPoints, geometry=gpd.points_from_xy(out_df_allPoints['longitude'],out_df_allPoints['latitude']), crs='epsg:4326')
        out_gdf.to_file(output_dir + "\Altimetry_Footprints_" + str(index_allPointsFile)+".shp")

#function for extracting Jason3 attributes
def extractJason3 (input_file_path_name: str, area_extent: gpd.GeoDataFrame):
    data=netCDF4.Dataset(input_file_path_name)
    
    passNum = data.pass_number
    cycleNum = data.cycle_number
    missionName = data.mission_name
    
    #read 1 Hz variables
    iono_corr_gim_ku=data.groups['data_01'].groups['ku'].variables['iono_cor_gim'][:]#*iono_corr_gim_ku_sc
    solid_earth_tide=data.groups['data_01'].variables['solid_earth_tide'][:]#*solid_earth_tide_sc
    pole_tide=data.groups['data_01'].variables['pole_tide'][:]#*pole_tide_sc
    geoid_egm08 = data.groups['data_01'].variables['geoid'][:]#geoid correction
    
    #create a dataframe to store the 1 Hz variable values
    mat_1HzVar = pd.DataFrame()
    mat_1HzVar['iono_cor_gim']=iono_corr_gim_ku
    mat_1HzVar['solid_earth_tide']=solid_earth_tide
    mat_1HzVar['pole_tide']=pole_tide
    mat_1HzVar['egm08']=geoid_egm08
    
    #read 20Hz variables --
    #create a dataframe to store the 20 Hz variable values
    mat_20HzVar = pd.DataFrame()
    
    indx_20hzIn01hz=data.groups['data_20'].variables['index_1hz_measurement'][:]        
    alt_20hz=data.groups['data_20'].variables['altitude'][:]
    lat_20hz=data.groups['data_20'].variables['latitude'][:]
    lon_20hz=data.groups['data_20'].variables['longitude'][:]
    time_20hz=data.groups['data_20'].variables['time'][:]
    model_dry_tropo_corr=data.groups['data_20'].variables['model_dry_tropo_cor_measurement_altitude'][:]
    model_wet_tropo_corr=data.groups['data_20'].variables['model_wet_tropo_cor_measurement_altitude'][:]
    ice_range_20hz_ku=data.groups['data_20'].groups['ku'].variables['range_ocog'][:]
    ice_sig0_20hz_ku=data.groups['data_20'].groups['ku'].variables['sig0_ocog'][:]
    ice_qual_flag_20hz_ku=data.groups['data_20'].groups['ku'].variables['ocog_qual'][:]
    
    #calculate the conversion from T/P ht to WGS84 ht
    #WGS84 is higher than T/P, therefore the elevation referenced to T/P is higher than the elevation referenced to WGS84
    #delHt = h2 - h1 =  -((a2 - a1) * cos(phi)^2 + (b2 - b1) * sin(phi)^2)
    wgs_a1 = 6378137.0 #meter
    wgs_b1 = 6356752.314245 #meter
    tp_a2 = 6378136.3 #meter
    tp_b2 = 6356751.600563 #meter
    delHt = -((tp_a2 - wgs_a1) * np.power(np.cos(np.radians(lat_20hz)), 2) + (tp_b2 - wgs_b1) * np.power(np.sin(np.radians(lat_20hz)), 2))
    
    #get the date from the 'time' variable. Seconds since 2000-01-01 00:00:00
    timeStamp2000 =  datetime(2000,1,1,00,00,00, tzinfo= timezone.utc).timestamp()
    secPassed = [x+timeStamp2000 for x in time_20hz]
    mat_20HzVar['dateTime']= pd.to_datetime(secPassed, unit='s')
    
    mat_20HzVar['date'] = mat_20HzVar['dateTime'].dt.date#only keep date
    
    mat_20HzVar['index_1hz'] = indx_20hzIn01hz
    mat_20HzVar['altitude'] = alt_20hz
    mat_20HzVar['latitude'] = lat_20hz
    mat_20HzVar['longitude'] = lon_20hz
    # convert longitude from (0-360) to (-180 to 180)
    mat_20HzVar['longitude'] = (mat_20HzVar['longitude'] +180)%360-180
    mat_20HzVar['time'] = time_20hz
    mat_20HzVar['dry_tropo'] = model_dry_tropo_corr
    mat_20HzVar['wet_tropo'] = model_wet_tropo_corr
    mat_20HzVar['range_ocog'] = ice_range_20hz_ku
    mat_20HzVar['sig0_ocog'] = ice_sig0_20hz_ku
    mat_20HzVar['ocog_qual'] = ice_qual_flag_20hz_ku
    mat_20HzVar['tp_wgs_conversion'] = delHt
        
    #extract 20 Hz data using lake extent [maxLat, minLat, maxLon, minLon]
    gdf_20Hzdata = gpd.GeoDataFrame(mat_20HzVar, geometry=gpd.points_from_xy(mat_20HzVar['longitude'],mat_20HzVar['latitude']), crs='epsg:4326')
    gdf_20HzdataInLake = gpd.clip(gdf_20Hzdata, area_extent)
    
    #merge 1Hz Var to 20Hz Var
    gdf_20HzdataInLake['index_1hz'] = gdf_20HzdataInLake['index_1hz'].astype('int64')
    gdf_20HzdataInLake = pd.merge_asof(gdf_20HzdataInLake.sort_values(by='index_1hz', ascending= True), mat_1HzVar.sort_index(ascending=True), left_on='index_1hz',right_index=True)
    
    #compute the heights
    gdf_20HzdataInLake['ht_tp'] = gdf_20HzdataInLake['altitude'] - gdf_20HzdataInLake['range_ocog'] - gdf_20HzdataInLake['dry_tropo'] - gdf_20HzdataInLake['wet_tropo'] - gdf_20HzdataInLake['iono_cor_gim'] - gdf_20HzdataInLake['solid_earth_tide'] - gdf_20HzdataInLake['pole_tide'] 
    
    gdf_20HzdataInLake['ht_wgs'] = gdf_20HzdataInLake['altitude'] - gdf_20HzdataInLake['range_ocog'] - gdf_20HzdataInLake['dry_tropo'] - gdf_20HzdataInLake['wet_tropo'] - gdf_20HzdataInLake['iono_cor_gim'] - gdf_20HzdataInLake['solid_earth_tide'] - gdf_20HzdataInLake['pole_tide'] - gdf_20HzdataInLake['tp_wgs_conversion']
    
    gdf_20HzdataInLake['ht_egm08'] = gdf_20HzdataInLake['altitude'] - gdf_20HzdataInLake['range_ocog'] - gdf_20HzdataInLake['dry_tropo'] - gdf_20HzdataInLake['wet_tropo'] - gdf_20HzdataInLake['iono_cor_gim'] - gdf_20HzdataInLake['solid_earth_tide'] - gdf_20HzdataInLake['pole_tide'] - gdf_20HzdataInLake['egm08']
    
    gdf_20HzdataInLake['mission'] = missionName
    gdf_20HzdataInLake['pass'] = passNum
    gdf_20HzdataInLake['cycle'] = cycleNum
    
    gdf_20HzdataInLake['MAD_score'] = calMADScore(gdf_20HzdataInLake['ht_egm08'])
    
    #drop the unnecessary columns
    gdf_20HzdataInLake = gdf_20HzdataInLake.drop(columns=['geometry','dateTime','time','index_1hz','altitude','dry_tropo','wet_tropo','range_ocog','sig0_ocog','ocog_qual','tp_wgs_conversion','iono_cor_gim','solid_earth_tide','pole_tide','egm08','ht_tp','ht_wgs'])
    
    return gdf_20HzdataInLake

#function for extracting Sentinel3 attributes
def extractSen3 (input_file_path_name: str, area_extent: gpd.GeoDataFrame):
    
    data=netCDF4.Dataset(input_file_path_name)
    
    passNum = data.pass_number
    cycleNum = data.cycle_number
    missionName = data.mission_name
    
    #read 1 Hz variables
    time_01=data.variables['time_01'][:]
    model_dry_tropo_corr=data.variables['mod_dry_tropo_cor_meas_altitude_01'][:]
    model_wet_tropo_corr=data.variables['mod_wet_tropo_cor_meas_altitude_01'][:]
    
    iono_corr_gim_ku=data.variables['iono_cor_gim_01_ku'][:]
    solid_earth_tide=data.variables['solid_earth_tide_01'][:]
    pole_tide=data.variables['pole_tide_01'][:]
    geoid_egm08 = data.variables['geoid_01'][:]
    
    #create a dataframe to store the 1 Hz variable values
    mat_1HzVar = pd.DataFrame()
    mat_1HzVar['time01'] = time_01
    mat_1HzVar['dry_tropo'] = model_dry_tropo_corr
    mat_1HzVar['wet_tropo'] = model_wet_tropo_corr
    mat_1HzVar['iono_cor_gim']=iono_corr_gim_ku
    mat_1HzVar['solid_earth_tide']=solid_earth_tide
    mat_1HzVar['pole_tide']=pole_tide
    mat_1HzVar['egm08']=geoid_egm08
    
    #read 20Hz variables --
    #create a dataframe to store the 20 Hz variable values
    mat_20HzVar = pd.DataFrame()
    
    time_20hz=data.variables['time_20_ku'][:]       
    alt_20hz=data.variables['alt_20_ku'][:]
    lat_20hz=data.variables['lat_20_ku'][:]
    lon_20hz=data.variables['lon_20_ku'][:]
    ocog_range_20hz_ku=data.variables['range_ocog_20_ku'][:]
    ocog_sig0_20hz_ku=data.variables['sig0_ocog_20_ku'][:]
     
        
    #get the date from the 'time' variable. Seconds since 2000-01-01 00:00:00
    timeStamp2000 =  datetime(2000,1,1,00,00,00, tzinfo= timezone.utc).timestamp()
    secPassed = [x+timeStamp2000 for x in time_20hz]
    mat_20HzVar['dateTime']= pd.to_datetime(secPassed, unit='s')
    
    mat_20HzVar['date'] = mat_20HzVar['dateTime'].dt.date#only keep date
    
    mat_20HzVar['altitude'] = alt_20hz
    mat_20HzVar['latitude'] = lat_20hz
    mat_20HzVar['longitude'] = lon_20hz
    # convert longitude from (0-360) to (-180 to 180)
    mat_20HzVar['longitude'] = (mat_20HzVar['longitude'] +180)%360-180
    mat_20HzVar['time20Hz'] = time_20hz
    mat_20HzVar['range_ocog'] = ocog_range_20hz_ku
    mat_20HzVar['sig0_ocog'] = ocog_sig0_20hz_ku
        
    #extract 20 Hz data using lake extent [maxLat, minLat, maxLon, minLon]
    gdf_20Hzdata = gpd.GeoDataFrame(mat_20HzVar, geometry=gpd.points_from_xy(mat_20HzVar['longitude'],mat_20HzVar['latitude']), crs='epsg:4326')
    gdf_20HzdataInLake = gpd.clip(gdf_20Hzdata, area_extent)
    
    #merge 1Hz Var to 20Hz Var  
    gdf_20HzdataInLake = pd.merge_asof(gdf_20HzdataInLake.sort_values(by='time20Hz', ascending= True), mat_1HzVar.sort_values(by = 'time01',ascending=True), left_on='time20Hz',right_on='time01', direction='nearest')
    
    #compute the heights    
    gdf_20HzdataInLake['ht_wgs'] = gdf_20HzdataInLake['altitude'] - gdf_20HzdataInLake['range_ocog'] - gdf_20HzdataInLake['dry_tropo'] - gdf_20HzdataInLake['wet_tropo'] - gdf_20HzdataInLake['iono_cor_gim'] - gdf_20HzdataInLake['solid_earth_tide'] - gdf_20HzdataInLake['pole_tide']
    
    gdf_20HzdataInLake['ht_egm08'] = gdf_20HzdataInLake['altitude'] - gdf_20HzdataInLake['range_ocog'] - gdf_20HzdataInLake['dry_tropo'] - gdf_20HzdataInLake['wet_tropo'] - gdf_20HzdataInLake['iono_cor_gim'] - gdf_20HzdataInLake['solid_earth_tide'] - gdf_20HzdataInLake['pole_tide'] - gdf_20HzdataInLake['egm08']
    
    gdf_20HzdataInLake['mission'] = missionName
    gdf_20HzdataInLake['pass'] = passNum
    gdf_20HzdataInLake['cycle'] = cycleNum
    
    gdf_20HzdataInLake['MAD_score'] = calMADScore(gdf_20HzdataInLake['ht_egm08'])
    
    gdf_20HzdataInLake = gdf_20HzdataInLake.drop(columns=['geometry','dateTime','time20Hz','altitude','dry_tropo','wet_tropo','range_ocog','sig0_ocog','time01','iono_cor_gim','solid_earth_tide','pole_tide','egm08','ht_wgs'])

    #write_to_file = open(output_file_path_name,"w")
    
    return gdf_20HzdataInLake

#function for extracting Sentinel6 attributes
def extractSen6 (input_file_path_name: str, area_extent: gpd.GeoDataFrame):
    data=netCDF4.Dataset(input_file_path_name)
    
    passNum = data.pass_number
    cycleNum = data.cycle_number
    missionName = data.mission_name
    
    #read 1 Hz variables
    time_1hz = data.groups['data_01'].variables['time'][:]
    iono_corr_gim_ku=data.groups['data_01'].groups['ku'].variables['iono_cor_gim'][:]#*iono_corr_gim_ku_sc
    solid_earth_tide=data.groups['data_01'].variables['solid_earth_tide'][:]#*solid_earth_tide_sc
    pole_tide=data.groups['data_01'].variables['pole_tide'][:]#*pole_tide_sc
    geoid_egm08 = data.groups['data_01'].variables['geoid'][:]#geoid correction
    
    #create a dataframe to store the 1 Hz variable values
    mat_1HzVar = pd.DataFrame()
    mat_1HzVar['time01']= time_1hz
    mat_1HzVar['iono_cor_gim']=iono_corr_gim_ku
    mat_1HzVar['solid_earth_tide']=solid_earth_tide
    mat_1HzVar['pole_tide']=pole_tide
    mat_1HzVar['egm08']=geoid_egm08
    
    #read 20Hz variables --
    #create a dataframe to store the 20 Hz variable values
    mat_20HzVar = pd.DataFrame()
    
    indx_20hzIn01hz=data.groups['data_20'].groups['ku'].variables['index_1hz_measurement'][:]        
    alt_20hz=data.groups['data_20'].groups['ku'].variables['altitude'][:]
    lat_20hz=data.groups['data_20'].groups['ku'].variables['latitude'][:]
    lon_20hz=data.groups['data_20'].groups['ku'].variables['longitude'][:]
    time_20hz=data.groups['data_20'].groups['ku'].variables['time'][:]
    model_dry_tropo_corr=data.groups['data_20'].groups['ku'].variables['model_dry_tropo_cor_measurement_altitude'][:]
    model_wet_tropo_corr=data.groups['data_20'].groups['ku'].variables['model_wet_tropo_cor_measurement_altitude'][:]
    ocog_range_20hz_ku=data.groups['data_20'].groups['ku'].variables['range_ocog'][:]
    ocog_sig0_20hz_ku=data.groups['data_20'].groups['ku'].variables['sig0_ocog'][:]
    
    #get the date from the 'time' variable. Seconds since 2000-01-01 00:00:00
    timeStamp2000 =  datetime(2000,1,1,00,00,00, tzinfo= timezone.utc).timestamp()
    secPassed = [x+timeStamp2000 for x in time_20hz]
    mat_20HzVar['dateTime']= pd.to_datetime(secPassed, unit='s')
    
    mat_20HzVar['date'] = mat_20HzVar['dateTime'].dt.date#only keep date
    
    mat_20HzVar['index_1hz'] = indx_20hzIn01hz
    mat_20HzVar['altitude'] = alt_20hz
    mat_20HzVar['latitude'] = lat_20hz
    mat_20HzVar['longitude'] = lon_20hz
    # convert longitude from (0-360) to (-180 to 180)
    mat_20HzVar['longitude'] = (mat_20HzVar['longitude'] +180)%360-180
    mat_20HzVar['time'] = time_20hz
    mat_20HzVar['dry_tropo'] = model_dry_tropo_corr
    mat_20HzVar['wet_tropo'] = model_wet_tropo_corr
    mat_20HzVar['range_ocog'] = ocog_range_20hz_ku
    mat_20HzVar['sig0_ocog'] = ocog_sig0_20hz_ku
        
    #extract 20 Hz data using lake polygon
    gdf_20Hzdata = gpd.GeoDataFrame(mat_20HzVar, geometry=gpd.points_from_xy(mat_20HzVar['longitude'],mat_20HzVar['latitude']), crs='epsg:4326')
    gdf_20HzdataInLake = gpd.clip(gdf_20Hzdata, area_extent)
    
    #merge 1Hz Var to 20Hz Var
    gdf_20HzdataInLake['index_1hz'] = gdf_20HzdataInLake['index_1hz'].astype('int64')
    gdf_20HzdataInLake = pd.merge_asof(gdf_20HzdataInLake.sort_values(by='index_1hz', ascending= True), mat_1HzVar.sort_index(ascending=True), left_on='index_1hz',right_index=True)
    
    #compute the heights
    gdf_20HzdataInLake['ht_wgs'] = gdf_20HzdataInLake['altitude'] - gdf_20HzdataInLake['range_ocog'] - gdf_20HzdataInLake['dry_tropo'] - gdf_20HzdataInLake['wet_tropo'] - gdf_20HzdataInLake['iono_cor_gim'] - gdf_20HzdataInLake['solid_earth_tide'] - gdf_20HzdataInLake['pole_tide'] 
    
    gdf_20HzdataInLake['ht_egm08'] = gdf_20HzdataInLake['altitude'] - gdf_20HzdataInLake['range_ocog'] - gdf_20HzdataInLake['dry_tropo'] - gdf_20HzdataInLake['wet_tropo'] - gdf_20HzdataInLake['iono_cor_gim'] - gdf_20HzdataInLake['solid_earth_tide'] - gdf_20HzdataInLake['pole_tide'] - gdf_20HzdataInLake['egm08']
    
    gdf_20HzdataInLake['mission'] = missionName
    gdf_20HzdataInLake['pass'] = passNum
    gdf_20HzdataInLake['cycle'] = cycleNum
    gdf_20HzdataInLake['MAD_score'] = calMADScore(gdf_20HzdataInLake['ht_egm08'])
    
    gdf_20HzdataInLake = gdf_20HzdataInLake.drop(columns=['geometry','dateTime','index_1hz','altitude','time','dry_tropo','wet_tropo','range_ocog','sig0_ocog','time01','iono_cor_gim','solid_earth_tide','pole_tide','egm08','ht_wgs'])

    #write_to_file = open(output_file_path_name,"w")
    
    return gdf_20HzdataInLake

#function for extracting SWOT attributes
def extractSWOT (input_file_path_name: str, area_extent: gpd.GeoDataFrame):
    data=netCDF4.Dataset(input_file_path_name)
    
    passNum = data.pass_number
    cycleNum = data.cycle_number
    missionName = data.mission_name
    
    #read 1 Hz variables
    time_1hz = data.groups['data_01'].variables['time'][:]
    iono_corr_gim_ku=data.groups['data_01'].groups['ku'].variables['iono_cor_gim'][:]#*iono_corr_gim_ku_sc
    solid_earth_tide=data.groups['data_01'].variables['solid_earth_tide'][:]#*solid_earth_tide_sc
    pole_tide=data.groups['data_01'].variables['pole_tide'][:]#*pole_tide_sc
    geoid_egm08 = data.groups['data_01'].variables['geoid'][:]#geoid correction
    dry_tropo = data.groups['data_01'].variables['model_dry_tropo_cor_measurement_altitude'][:]
    wet_tropo = data.groups['data_01'].variables['model_wet_tropo_cor_measurement_altitude'][:]
    
    #create a dataframe to store the 1 Hz variable values
    mat_1HzVar = pd.DataFrame()
    mat_1HzVar['time01']= time_1hz
    mat_1HzVar['iono_cor_gim']=iono_corr_gim_ku
    mat_1HzVar['solid_earth_tide']=solid_earth_tide
    mat_1HzVar['pole_tide']=pole_tide
    mat_1HzVar['egm08']=geoid_egm08
    mat_1HzVar['dry_tropo'] = dry_tropo
    mat_1HzVar['wet_tropo'] = wet_tropo
    
    #read 20Hz variables --
    #create a dataframe to store the 20 Hz variable values
    mat_20HzVar = pd.DataFrame()
    
    indx_20hzIn01hz=data.groups['data_20'].variables['index_1hz_measurement'][:]        
    alt_20hz=data.groups['data_20'].variables['altitude'][:]
    lat_20hz=data.groups['data_20'].variables['latitude'][:]
    lon_20hz=data.groups['data_20'].variables['longitude'][:]
    time_20hz=data.groups['data_20'].variables['time'][:]
    ice_range_20hz_ku=data.groups['data_20'].groups['ku'].variables['range_ocog'][:]
    ice_sig0_20hz_ku=data.groups['data_20'].groups['ku'].variables['sig0_ocog'][:]
    ice_qual_flag_20hz_ku=data.groups['data_20'].groups['ku'].variables['ocog_qual'][:]
       
    #get the date from the 'time' variable. Seconds since 2000-01-01 00:00:00
    timeStamp2000 =  datetime(2000,1,1,00,00,00, tzinfo= timezone.utc).timestamp()
    secPassed = [x+timeStamp2000 for x in time_20hz]
    mat_20HzVar['dateTime']= pd.to_datetime(secPassed, unit='s')
    
    mat_20HzVar['date'] = mat_20HzVar['dateTime'].dt.date#only keep date
    
    mat_20HzVar['index_1hz'] = indx_20hzIn01hz
    mat_20HzVar['altitude'] = alt_20hz
    mat_20HzVar['latitude'] = lat_20hz
    mat_20HzVar['longitude'] = lon_20hz
    mat_20HzVar['time'] = time_20hz
    mat_20HzVar['range_ocog'] = ice_range_20hz_ku
    mat_20HzVar['sig0_ocog'] = ice_sig0_20hz_ku
    mat_20HzVar['ocog_qual'] = ice_qual_flag_20hz_ku
        
    #extract 20 Hz data using lake extent [maxLat, minLat, maxLon, minLon]
    gdf_20Hzdata = gpd.GeoDataFrame(mat_20HzVar, geometry=gpd.points_from_xy(mat_20HzVar['longitude'],mat_20HzVar['latitude']), crs='epsg:4326')
    gdf_20HzdataInLake = gpd.clip(gdf_20Hzdata, area_extent)
    
    #merge 1Hz Var to 20Hz Var
    gdf_20HzdataInLake['index_1hz'] = gdf_20HzdataInLake['index_1hz'].astype('int64')
    gdf_20HzdataInLake = pd.merge_asof(gdf_20HzdataInLake.sort_values(by='index_1hz', ascending= True), mat_1HzVar.sort_index(ascending=True), left_on='index_1hz',right_index=True)
    
    #compute the heights
    gdf_20HzdataInLake['ht_wgs'] = gdf_20HzdataInLake['altitude'] - gdf_20HzdataInLake['range_ocog'] - gdf_20HzdataInLake['dry_tropo'] - gdf_20HzdataInLake['wet_tropo'] - gdf_20HzdataInLake['iono_cor_gim'] - gdf_20HzdataInLake['solid_earth_tide'] - gdf_20HzdataInLake['pole_tide'] 
        
    gdf_20HzdataInLake['ht_egm08'] = gdf_20HzdataInLake['altitude'] - gdf_20HzdataInLake['range_ocog'] - gdf_20HzdataInLake['dry_tropo'] - gdf_20HzdataInLake['wet_tropo'] - gdf_20HzdataInLake['iono_cor_gim'] - gdf_20HzdataInLake['solid_earth_tide'] - gdf_20HzdataInLake['pole_tide'] - gdf_20HzdataInLake['egm08']
    
    gdf_20HzdataInLake['mission'] = missionName
    gdf_20HzdataInLake['pass'] = passNum
    gdf_20HzdataInLake['cycle'] = cycleNum
    gdf_20HzdataInLake['MAD_score'] = calMADScore(gdf_20HzdataInLake['ht_egm08'])
      
    gdf_20HzdataInLake = gdf_20HzdataInLake.drop(columns=['geometry','dateTime','index_1hz','altitude','time','dry_tropo','wet_tropo','range_ocog','sig0_ocog','ocog_qual','time01','iono_cor_gim','solid_earth_tide','pole_tide','egm08','ht_wgs'])

    #calculate the MAD score for each measurements
  
    
    return gdf_20HzdataInLake

#function for removing outliers with MAD
def calMADScore(profile:pd.Series):
    #replace the nan value with a super low value, so that it will be filtered out later
    profile = profile.replace(np.nan, -10000.0)
    median= np.median(profile)
    #1.4826 is a correction term that makes the MAD equal to the standard deviation of a normal distribution
    MAD = 1.4826 * stats.median_abs_deviation(profile)
        
    #calculate the absolute MAD score
    MAD_score = np.abs((profile - median)/MAD)
     
    return MAD_score

def calWaterLevel(df_points):
    out_df = pd.DataFrame(columns= ['mission', 'date', 'pass', 'cycle', 'waterLevel_EGM08', 'numPnts', 'STD'])
    
    mission = df_points['mission'].values[0]
    date = df_points['date'].values[0]
    passNum = df_points['pass'].values[0]
    cycleNum = df_points['cycle'].values[0]
    
    #filter out the points with MAD Score > 3
    df_GoodPnts = df_points[df_points['MAD_score']<3.0].copy()
    if len(df_GoodPnts) >= 3:
        waterLevel = df_GoodPnts['ht_egm08'].median()
        numPnt = df_GoodPnts['ht_egm08'].count()
        std_water = df_GoodPnts['ht_egm08'].std() 
        out_df.loc[0] = [mission, date, passNum, cycleNum, waterLevel, numPnt, std_water]
    else:
        out_df.loc[0] = [mission, date, 2147483647, 2147483647, 2147483647]
    
    return out_df
