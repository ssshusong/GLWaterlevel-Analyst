import pandas as pd
from datetime import datetime,timezone
import geopandas as gpd
from subscriber import podaac_data_downloader as pdd, podaac_access as pa
from shapely.geometry import LineString
import os
import numpy as np
import requests
import json
import time
from ftplib import FTP
import xarray as xs
from pyproj import CRS
# import ctypes
# from qgis.PyQt.QtWidgets import QMessageBox

# def show_message(title, message):
#         msg_box = QMessageBox()
#         msg_box.setIcon(QMessageBox.Information)
#         msg_box.setWindowTitle(title)
#         msg_box.setText(message)
#         msg_box.exec_()  # Blocks only the dialog, not your whole app

#function for downloading SWOT LR SSH raster data Version2 - Expert 
def downloadSWOT_SSH_Nominal(lake_shp: gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir:str):
    #project the shapefile to WGS 1984 first. The spatial search is based on the latitude and longitude.
    lake_shp = lake_shp.to_crs(crs='epsg:4326')
    
    LakeBound=lake_shp.total_bounds
    lake_minLon = LakeBound[0]
    lake_maxLon = LakeBound[2]
    lake_minLat = LakeBound[1]
    lake_maxLat = LakeBound[3]
    
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    
    # arg_parser = pdd.create_parser()
    pa.setup_earthdata_login_auth(pa.edl)
    token = pa.get_token(pa.token_url)
    
    #The bounding rectangle to filter result in. Format is W Longitude,S Latitude,E Longitude,N Latitude without spaces. Due to an issue with parsing arguments, to use this command, please use the -b="-180,-90,180,90" syntax 
    # arg_str_SWOT = ('-c SWOT_L2_LR_SSH_EXPERT_2.0 -d ' + outputFile_Dir + ' -gr SWOT_L2_LR_SSH_Expert_*PGC* '+  ' -b='+str(lake_minLon) +','+str(lake_minLat)+','+str(lake_maxLon)+','+str(lake_maxLat)+ ' -sd ' + start_date_str + ' -ed ' + end_date_str).split()
    
    # args = arg_parser.parse_args(arg_str_SWOT)

    # --- WORKAROUND APPLIED HERE ---
    class MockArgs: pass
    args = MockArgs()
    args.collection = 'SWOT_L2_LR_SSH_EXPERT_2.0'
    args.outputDirectory = outputFile_Dir
    args.granulename = 'SWOT_L2_LR_SSH_Expert_*PGC*'
    args.bbox = f"{lake_minLon},{lake_minLat},{lake_maxLon},{lake_maxLat}"
    args.startDate = start_date_str
    args.endDate = end_date_str
    args.provider = 'POCLOUD'
    args.verbose = False
    args.force = False
    # --- END OF WORKAROUND ---
    
    cmr_granule = (args.granulename).rsplit(".",1)[0]
    temporal_range = pa.get_temporal_range(args.startDate, args.endDate, datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"))
    
    params = [
        ('page_size', 2000),
        ('sort_key', "-start_date"),
        ('provider', args.provider),
        ('ShortName', args.collection),
        ('GranuleUR[]', cmr_granule),
        ('temporal', temporal_range),
        ('bounding_box',args.bbox),
        ('token', token),
    ]
    
    if '*' in cmr_granule or '?' in cmr_granule:
        params.append(('options[GranuleUR][pattern]', 'true'))
    
    results = pa.get_search_results(params, args.verbose)
    
    downloads_all = []
    downloads_data = [[u['URL'] for u in r['umm']['RelatedUrls'] if u['Type'] == "GET DATA" and ('Subtype' not in u or u['Subtype'] != "OPENDAP DATA")] for r in results['items']]
    
    checksums = pa.extract_checksums(results)
    for f in downloads_data:
        downloads_all.append(f)

    downloads = [item for sublist in downloads_all for item in sublist]
    for f in downloads:
        # -d flag, args.outputDirectory
        output_path = os.path.join(args.outputDirectory, os.path.basename(f))
        
        # decide if we should actually download this file (e.g. we may already have the latest version)
        if(os.path.exists(output_path) and not args.force and pa.checksum_does_match(output_path, checksums)):
            continue

        pa.download_file(f,output_path)
        #urlretrieve(f, output_path) 

    return None

def downloadSWOT_Raster(lake_shp: gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir:str):
    lake_shp_pcs = lake_shp.to_crs(lake_shp.estimate_utm_crs())
    lake_minWidth = polygon_width(lake_shp_pcs.geometry)
    
    #for the super lakes, download low rate SSH data
    if (lake_minWidth/1000) <120: downloadSWOT_HR_Raster(lake_shp, start_date, end_date, outputFile_Dir)
    else: downloadSWOT_SSH_Nominal(lake_shp, start_date, end_date, outputFile_Dir)
    
    return None

def polygon_width(polygon):
    """Approximates the width of a polygon."""

    # Create the oriented bounding box (minimum rotated rectangle)
    obb = polygon.minimum_rotated_rectangle()

    # Get the vertices of the OBB
    obb_coords = (obb.exterior.get_coordinates()).reset_index(drop = True)

    # Calculate the lengths of the two sides of the OBB
    side1_length = LineString([obb_coords.loc[0], obb_coords.loc[1]]).length
    side2_length = LineString([obb_coords.loc[1], obb_coords.loc[2]]).length

    # The width is the shorter side
    return min(side1_length, side2_length)

#function for downloading SWOT HR raster data Version2 - 250 m
def downloadSWOT_HR_Raster(lake_shp: gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir:str):
    #project the shapefile to WGS 1984 first. The spatial search is based on the latitude and longitude.
    lake_shp = lake_shp.to_crs(crs='epsg:4326')
    LakeBound=lake_shp.total_bounds
    lake_minLon = LakeBound[0]
    lake_maxLon = LakeBound[2]
    lake_minLat = LakeBound[1]
    lake_maxLat = LakeBound[3]
    
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    
    # arg_parser = pdd.create_parser()
    pa.setup_earthdata_login_auth(pa.edl)
    token = pa.get_token(pa.token_url)
    
    #The bounding rectangle to filter result in. Format is W Longitude,S Latitude,E Longitude,N Latitude without spaces. Due to an issue with parsing arguments, to use this command, please use the -b="-180,-90,180,90" syntax 
    # arg_str_SWOT = ('-c SWOT_L2_HR_Raster_250m_2.0 -d ' + outputFile_Dir + ' -gr SWOT_L2_HR_Raster_250m_*_PIC* '+  ' -b='+str(lake_minLon) +','+str(lake_minLat)+','+str(lake_maxLon)+','+str(lake_maxLat)+ ' -sd ' + start_date_str + ' -ed ' + end_date_str).split()
    
    # args = arg_parser.parse_args(arg_str_SWOT)

    # --- WORKAROUND APPLIED HERE ---
    class MockArgs: pass
    args = MockArgs()
    args.collection = 'SWOT_L2_HR_Raster_250m_2.0'
    args.outputDirectory = outputFile_Dir
    args.granulename = 'SWOT_L2_HR_Raster_250m_*_PIC*'
    args.bbox = f"{lake_minLon},{lake_minLat},{lake_maxLon},{lake_maxLat}"
    args.startDate = start_date_str
    args.endDate = end_date_str
    args.provider = 'POCLOUD'
    args.verbose = False
    args.force = False
    # --- END OF WORKAROUND ---

    cmr_granule = (args.granulename).rsplit(".",1)[0]
    temporal_range = pa.get_temporal_range(args.startDate, args.endDate, datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"))
    
    params = [
        ('page_size', 2000),
        ('sort_key', "-start_date"),
        ('provider', args.provider),
        ('ShortName', args.collection),
        ('GranuleUR[]', cmr_granule),
        ('temporal', temporal_range),
        ('bounding_box',args.bbox),
        ('token', token),
    ]
    
    if '*' in cmr_granule or '?' in cmr_granule:
        params.append(('options[GranuleUR][pattern]', 'true'))
    
    results = pa.get_search_results(params, args.verbose)
    
    downloads_all = []
    downloads_data = [[u['URL'] for u in r['umm']['RelatedUrls'] if u['Type'] == "GET DATA" and ('Subtype' not in u or u['Subtype'] != "OPENDAP DATA")] for r in results['items']]
    
    checksums = pa.extract_checksums(results)
    for f in downloads_data:
        downloads_all.append(f)

    downloads = [item for sublist in downloads_all for item in sublist]
    for f in downloads:
        # -d flag, args.outputDirectory
        output_path = os.path.join(args.outputDirectory, os.path.basename(f))
        
        # decide if we should actually download this file (e.g. we may already have the latest version)
        if(os.path.exists(output_path) and not args.force and pa.checksum_does_match(output_path, checksums)):
            continue

        pa.download_file(f,output_path)
        #urlretrieve(f, output_path) 

    return None

#function for downloading SWOT nadir profiling altimetry data GDR Version 2.0.
def downloadSWOT_nadir_Ver2(lake_shp:gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir):
    # lake_shp = gpd.read_file(lake_shp_pathName, drivers = 'shapefile')
    
    # lake_name = lake_shp['Name']
    #get satellite pass numbers
    # passNumStr_swot = (lake_shp['SWOT_Pass'].values[0]).split(',')
    
    #project the shapefile to WGS 1984 first. The spatial search is based on the latitude and longitude.
    lake_shp = lake_shp.to_crs(crs='epsg:4326')
    
    LakeBound=lake_shp.total_bounds
    lake_minLon = LakeBound[0]
    lake_maxLon = LakeBound[2]
    lake_minLat = LakeBound[1]
    lake_maxLat = LakeBound[3]
    
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    
    # arg_parser = pdd.create_parser()
    
    pa.setup_earthdata_login_auth(pa.edl)
    token = pa.get_token(pa.token_url)
    
    # arg_str_SWOT = ('-c SWOT_L2_NALT_GDR_GDR_2.0 -d ' + outputFile_Dir +  ' -gr SWOT_GPN_*' + ' -b='+str(lake_minLon) +','+str(lake_minLat)+','+str(lake_maxLon)+','+str(lake_maxLat) + ' -sd ' + start_date_str + ' -ed ' + end_date_str).split()
                        #) +' -b ' + str(lake_minLon)+','+str(lake_minLat)+','+str(lake_maxLon)+','+str(lake_maxLat) 

        # pdd.run(args)
        
    # args = arg_parser.parse_args(arg_str_SWOT)

    # --- WORKAROUND APPLIED HERE ---
    class MockArgs: pass
    args = MockArgs()
    args.collection = 'SWOT_L2_NALT_GDR_GDR_2.0'
    args.outputDirectory = outputFile_Dir
    args.granulename = 'SWOT_GPN_*'
    args.bbox = f"{lake_minLon},{lake_minLat},{lake_maxLon},{lake_maxLat}"
    args.startDate = start_date_str
    args.endDate = end_date_str
    args.provider = 'POCLOUD'
    args.verbose = False
    args.force = False
    # --- END OF WORKAROUND ---

    cmr_granule = (args.granulename).rsplit(".",1)[0]
    temporal_range = pa.get_temporal_range(args.startDate, args.endDate, datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"))
    
    params = [
        ('page_size', 2000),
        ('sort_key', "-start_date"),
        ('provider', args.provider),
        ('ShortName', args.collection),
        ('GranuleUR[]', cmr_granule),
        ('temporal', temporal_range),
        ('bounding_box',args.bbox),
        ('token', token),
    ]
    
    if '*' in cmr_granule or '?' in cmr_granule:
        params.append(('options[GranuleUR][pattern]', 'true'))
    
    results = pa.get_search_results(params, args.verbose)
    
    downloads_all = []
    downloads_data = [[u['URL'] for u in r['umm']['RelatedUrls'] if u['Type'] == "GET DATA" and ('Subtype' not in u or u['Subtype'] != "OPENDAP DATA")] for r in results['items']]
    
    checksums = pa.extract_checksums(results)

    for f in downloads_data:
        downloads_all.append(f)

    downloads = [item for sublist in downloads_all for item in sublist]
    for f in downloads:
        # -d flag, args.outputDirectory
        output_path = os.path.join(args.outputDirectory, os.path.basename(f))
        
        # decide if we should actually download this file (e.g. we may already have the latest version)
        if(os.path.exists(output_path) and not args.force and pa.checksum_does_match(output_path, checksums)):
            continue

        pa.download_file(f,output_path)
        #urlretrieve(f, output_path) 

#function for downloading Sen6 data
def downloadSen6(lake_shp:gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir):
    # lake_shp = gpd.read_file(lake_shp_pathName, drivers = 'shapefile')
    lake_name = lake_shp['Name']    
    passNumStr_Sen6a = (lake_shp['Sen6A_Pass'].values[0]).split(',')
    #format the start date and end date as string
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    
    arg_parser = pdd.create_parser()
    
    if passNumStr_Sen6a is not None:
        pa.setup_earthdata_login_auth(pa.edl)
        token = pa.get_token(pa.token_url)
            
        for temp_Sen6aPass in passNumStr_Sen6a:
            arg_str_Sen6a = ('-c JASON_CS_S6A_L2_ALT_HR_STD_OST_NTC_F08_UNVALIDATED -d ' + outputFile_Dir + ' -gr *_'+ temp_Sen6aPass +'_* ' + ' -sd ' + start_date_str + ' -ed ' + end_date_str).split()
            
            args = arg_parser.parse_args(arg_str_Sen6a)
            cmr_granule = (args.granulename).rsplit(".",1)[0]
            temporal_range = pa.get_temporal_range(args.startDate, args.endDate, datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
            
            params = [
                ('page_size', 2000),
                ('sort_key', "-start_date"),
                ('provider', args.provider),
                ('ShortName', args.collection),
                ('GranuleUR[]', cmr_granule),
                ('temporal', temporal_range),
                ('token', token),
            ]
            
            if '*' in cmr_granule or '?' in cmr_granule:
                params.append(('options[GranuleUR][pattern]', 'true'))
            
            results = pa.get_search_results(params, args.verbose)
            
            downloads_all = []
            downloads_data = [[u['URL'] for u in r['umm']['RelatedUrls'] if u['Type'] == "GET DATA" and ('Subtype' not in u or u['Subtype'] != "OPENDAP DATA")] for r in results['items']]
            
            checksums = pa.extract_checksums(results)

            for f in downloads_data:
                downloads_all.append(f)

            downloads = [item for sublist in downloads_all for item in sublist]
            for f in downloads:
                # -d flag, args.outputDirectory
                output_path = os.path.join(args.outputDirectory, os.path.basename(f))
                
                # decide if we should actually download this file (e.g. we may already have the latest version)
                if(os.path.exists(output_path) and not args.force and pa.checksum_does_match(output_path, checksums)):
                    continue
                pa.download_file(f,output_path)
    else:
        print('There is no Sentinel-6A ground track over ' + lake_name)     
    # region: Download Sen6 data using lake extent
    # #get the extent of the lake,
    # maxLat = str(lake_shp['MaxLat'].values[0])
    # minLat = str(lake_shp['MinLat'].values[0])
    # maxLon = str(lake_shp['MaxLon'].values[0])
    # minLon = str(lake_shp['MinLon'].values[0])

    # arg_str_Sen6a = ('-c JASON_CS_S6A_L2_ALT_HR_STD_OST_NTC_F08_UNVALIDATED -d '+ output_data_folder+ ' -b ' + minLon+','+ minLat +','+maxLon+','+maxLat + ' -sd ' + start_date + ' -ed ' + end_date + ' --verbose').split()
    # args = arg_parser.parse_args(arg_str_Sen6a)
    # pdd.run(args)
    #endregion

#function for downloading Sen6 data using bounding box
def downloadSen6_bbox(lake_shp: gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir):
    # lake_name = lake_shp['Name']    
    # passNumStr_Sen6a = (lake_shp['Sen6A_Pass'].values[0]).split(',')
    
    #project the shapefile to WGS 1984 first. The spatial search is based on the latitude and longitude.
    lake_shp = lake_shp.to_crs(crs='epsg:4326')
    
    LakeBound=lake_shp.total_bounds
    lake_minLon = LakeBound[0]
    lake_maxLon = LakeBound[2]
    lake_minLat = LakeBound[1]
    lake_maxLat = LakeBound[3]
    
    #format the start date and end date as string
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    
    arg_parser = pdd.create_parser()

    pa.setup_earthdata_login_auth(pa.edl)
    token = pa.get_token(pa.token_url)
        
    arg_str_Sen6a = ('-c JASON_CS_S6A_L2_ALT_HR_STD_OST_NTC_F08_UNVALIDATED -d ' + outputFile_Dir + ' -gr S6A_P4_2__HR_STD__NT_*_unvalidated' + ' -b='+str(lake_minLon) +','+str(lake_minLat)+','+str(lake_maxLon)+','+str(lake_maxLat) +  ' -sd ' + start_date_str + ' -ed ' + end_date_str).split()
    
    args = arg_parser.parse_args(arg_str_Sen6a)
    cmr_granule = (args.granulename).rsplit(".",1)[0]
    temporal_range = pa.get_temporal_range(args.startDate, args.endDate, datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
    
    params = [
        ('page_size', 2000),
        ('sort_key', "-start_date"),
        ('provider', args.provider),
        ('ShortName', args.collection),
        ('GranuleUR[]', cmr_granule),
        ('temporal', temporal_range),
        ('bounding_box',args.bbox),
        ('token', token),
    ]
    
    if '*' in cmr_granule or '?' in cmr_granule:
        params.append(('options[GranuleUR][pattern]', 'true'))
    
    results = pa.get_search_results(params, args.verbose)
    
    downloads_all = []
    downloads_data = [[u['URL'] for u in r['umm']['RelatedUrls'] if u['Type'] == "GET DATA" and ('Subtype' not in u or u['Subtype'] != "OPENDAP DATA")] for r in results['items']]
    
    checksums = pa.extract_checksums(results)

    for f in downloads_data:
        downloads_all.append(f)

    downloads = [item for sublist in downloads_all for item in sublist]
    for f in downloads:
        # -d flag, args.outputDirectory
        output_path = os.path.join(args.outputDirectory, os.path.basename(f))
        
        # decide if we should actually download this file (e.g. we may already have the latest version)
        if(os.path.exists(output_path) and not args.force and pa.checksum_does_match(output_path, checksums)):
            continue
        pa.download_file(f,output_path)

#function for downloading Sen6 data using lake polygon to identify pass number
def downloadSen6_shp_pass(lake_shp: gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir, this_plugin_dir):
    #identify the pass number for this lake
    passNumStr_s6a_nominal = identifyS6APass(lake_shp,this_plugin_dir)
    passNumStr_s6a_nominal = passNumStr_s6a_nominal.split(',')
  
    # lake_name = lake_shp['Name']    
    passNumStr_Sen6a = passNumStr_s6a_nominal
    #format the start date and end date as string
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    
    # arg_parser = pdd.create_parser()
    
    if passNumStr_Sen6a is not None:
        pa.setup_earthdata_login_auth(pa.edl)
        token = pa.get_token(pa.token_url)

        # --- WORKAROUND APPLIED HERE ---
        class MockArgs: pass
        args = MockArgs()
        args.collection = 'JASON_CS_S6A_L2_ALT_HR_STD_OST_NTC_F08_UNVALIDATED'
        args.outputDirectory = outputFile_Dir
        # args.granulename = 'S6A_P4_2__HR_STD__NT_*_unvalidated'
        # args.bbox = f"{lake_minLon},{lake_minLat},{lake_maxLon},{lake_maxLat}"
        args.startDate = start_date_str
        args.endDate = end_date_str
        args.provider = 'POCLOUD'
        args.verbose = False 
        args.force = False
        # --- END OF WORKAROUND ---
            
        for temp_Sen6aPass in passNumStr_Sen6a:
            if temp_Sen6aPass == '': continue

            # arg_str_Sen6a = ('-c JASON_CS_S6A_L2_ALT_HR_STD_OST_NTC_F08_UNVALIDATED -d ' + outputFile_Dir + ' -gr *_'+ temp_Sen6aPass +'_* ' + ' -sd ' + start_date_str + ' -ed ' + end_date_str).split()            
            # args = arg_parser.parse_args(arg_str_Sen6a)
            args.granulename = '*_'+ temp_Sen6aPass + '_*'

            cmr_granule = (args.granulename).rsplit(".",1)[0]
            temporal_range = pa.get_temporal_range(args.startDate, args.endDate, datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
            
            params = [
                ('page_size', 2000),
                ('sort_key', "-start_date"),
                ('provider', args.provider),
                ('ShortName', args.collection),
                ('GranuleUR[]', cmr_granule),
                ('temporal', temporal_range),
                ('token', token),
            ]
            
            if '*' in cmr_granule or '?' in cmr_granule:
                params.append(('options[GranuleUR][pattern]', 'true'))
            
            results = pa.get_search_results(params, args.verbose)
            
            downloads_all = []
            downloads_data = [[u['URL'] for u in r['umm']['RelatedUrls'] if u['Type'] == "GET DATA" and ('Subtype' not in u or u['Subtype'] != "OPENDAP DATA")] for r in results['items']]
            
            checksums = pa.extract_checksums(results)

            for f in downloads_data:
                downloads_all.append(f)

            downloads = [item for sublist in downloads_all for item in sublist]
            for f in downloads:
                # -d flag, args.outputDirectory
                output_path = os.path.join(args.outputDirectory, os.path.basename(f))
                
                # decide if we should actually download this file (e.g. we may already have the latest version)
                if(os.path.exists(output_path) and not args.force and pa.checksum_does_match(output_path, checksums)):
                    continue
                pa.download_file(f,output_path)
    else:
        print('There is no Sentinel-6A ground track over this lake')     

#function for identifying jason-3 pass
def identifyS6APass(lake_shp: gpd.GeoDataFrame, this_plugin_dir):
    # s6aPass_shp_int = gpd.read_file(os.path.join(os.getcwd(), 'TP_Jason_Interval.shp'))
    s6aPass_shp_nom = gpd.read_file(os.path.join(this_plugin_dir, 'TP_Jason_Nominal.shp'))
    
    #create a copy of lake shapefile
    lake_shp_copy = lake_shp.copy(deep=True)
    #convert crs of lake polygon to the same with the pass shapefiles.
    if lake_shp_copy.crs != s6aPass_shp_nom.crs:
        lake_shp_copy = lake_shp_copy.to_crs(s6aPass_shp_nom.crs)
    
    lake_poly = lake_shp_copy.geometry.iloc[0]  
    
    # int_passes = ja3Pass_shp_int[ja3Pass_shp_int.intersects(lake_poly)]        
    nom_passes = s6aPass_shp_nom[s6aPass_shp_nom.intersects(lake_poly)]
    #pad the Track numbers with leading zeros so that each is exactly 3 digits — for example:
    # 1 → "001"
    # 12 → "012"
    # 205 → "205"
    # int_passes_str = ",".join(f"{int(t):03d}" for t in int_passes['Track'].tolist())
    nom_passes_str = ",".join(f"{int(t):03d}" for t in nom_passes['Track'].tolist())
    
    return nom_passes_str

#function for downloading Sen3A data
def downloadSen3A(lake_shp: gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir, esa_user, esa_password):
    #download Sentinel-3 data from Copernicus Data Space Ecocystem using OData
    # base URL of the product catalogue
    catalogue_odata_url = "https://catalogue.dataspace.copernicus.eu/odata/v1"
    # search parameters
    collection_name = "SENTINEL-3"
    product_type = "SR_2_LAN_HY"
    timeliness = "NT"
        
    #format the start date and end date as string
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    
    #get lake extent
    #project the shapefile to WGS 1984 first. The spatial search is based on the latitude and longitude.
    lake_shp = lake_shp.to_crs(crs='epsg:4326')
    # lake_maxLat = lake_shp['MaxLat'].values[0]
    # lake_minLat = lake_shp['MinLat'].values[0]
    # lake_maxLon = lake_shp['MaxLon'].values[0]
    # lake_minLon = lake_shp['MinLon'].values[0]
    LakeBound=lake_shp.total_bounds
    lake_minLon = LakeBound[0]
    lake_maxLon = LakeBound[2]
    lake_minLat = LakeBound[1]
    lake_maxLat = LakeBound[3]
    
    #AOI is defined by the four corners of the lake extent
    aoi = 'POLYGON(('+ str(lake_minLon)+' '+ str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_minLat)+','+ str(lake_minLon)+' '+str(lake_minLat)+','+str(lake_minLon)+' '+str(lake_maxLat)+'))'
    #second polygon: ,(30.19 2.19, 31.4 2.19, 31.4 1.0, 30.19 1.0, 30.19 2.19)
    
    # relOrbit = 127
    #and Attributes/OData.CSC.IntegerAttribute/any(att:att/Name eq 'relativeOrbitNumber' and att/OData.CSC.IntegerAttribute/Value eq '{relOrbit}')
    #max_cloud_cover = 1
    #AOI is defined by the four corners of the lake extent
    # aoi = 'POLYGON(('+ str(lake_minLon)+' '+ str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_minLat)+','+ str(lake_minLon)+' '+str(lake_minLat)+','+str(lake_minLon)+' '+str(lake_maxLat)+'))'
    #second polygon: ,(30.19 2.19, 31.4 2.19, 31.4 1.0, 30.19 1.0, 30.19 2.19)
    # search_period_start = "2023-06-01T00:00:00.000Z"
    # search_period_end = "2023-06-10T00:00:00.000Z"

    #build search query 
    search_query = f"{catalogue_odata_url}/Products?$filter=Collection/Name eq '{collection_name}' and contains(Name, 'S3A') and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'productType' and att/OData.CSC.StringAttribute/Value eq '{product_type}') and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'timeliness' and att/OData.CSC.StringAttribute/Value eq '{timeliness}') and OData.CSC.Intersects(area=geography'SRID=4326;{aoi}') and ContentDate/Start gt {start_date_str} and ContentDate/Start lt {end_date_str}&$top=999"

    #run the query and display the results
    response = requests.get(search_query).json()
    result = pd.DataFrame.from_dict(response["value"])

    if not result.empty:
        #select the products
        product_identifiers = result.iloc[:,1]
        product_names = result.iloc[:,2]

        # Get authentication token
        auth_server_url = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
        data = {
            "client_id": "cdse-public",
            "grant_type": "password",
            "username": esa_user,
            "password": esa_password,
        }
        response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
        access_token = json.loads(response.text)["access_token"]
        refresh_token = json.loads(response.text)["refresh_token"]

        #get session start time
        session_start_time = time.time()
        session_renew_time = session_start_time

        # Establish session
        session = requests.Session()
        # headers = {"Authorization": f"Bearer {access_token}"}
        session.headers["Authorization"] = f"Bearer {access_token}"
        #session.headers.update({'Authorization': f'Bearer {access_token}'})

        for i in range(len(product_identifiers)):
            product_nm = (product_names[i]).split('.')[0]+'_standard.nc'
            url = f"{catalogue_odata_url}/Products({product_identifiers[i]})/Nodes({product_names[i]})/Nodes(standard_measurement.nc)/$value"
            #print(url)
        
            response = session.get(url, allow_redirects=False)
            if response.status_code in (301, 302, 303, 307):
                url = response.headers["Location"]
                # response = session.get(url, allow_redirects=False)
            
            currentTime = time.time()
            time_sinceRenew =  session_renew_time
            time_sinceStart = currentTime - session_start_time
            
            #session times out in 10 minutes, and totally expires in 60 minutes
            if response.status_code in (401,403) or (time_sinceRenew >= 600 and time_sinceStart < 3600):
                data = {
                "client_id": "cdse-public",
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,        
                }
                response = requests.post(auth_server_url, data=data, verify=False, allow_redirects=False)
                access_token = json.loads(response.text)["access_token"]
                session = requests.Session()
                session.headers["Authorization"] = f"Bearer {access_token}"
                session_renew_time = time.time()
            
            if time_sinceStart >= 3600:
                data = {
                    "client_id": "cdse-public",
                    "grant_type": "password",
                    "username": esa_user,
                    "password": esa_password,
                }
                response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
                access_token = json.loads(response.text)["access_token"]
                refresh_token = json.loads(response.text)["refresh_token"]

                # Establish session
                session = requests.Session()
                # headers = {"Authorization": f"Bearer {access_token}"}
                session.headers["Authorization"] = f"Bearer {access_token}"        
                session_start_time = time.time()
            
            # session.headers.update(headers)
            
            #save the data to local directory
            outfile = os.path.join(outputFile_Dir, product_nm)
            if os.path.exists(outfile):
                continue
            
            #download the data
            file = session.get(url, verify=False, allow_redirects=True)
            
            with open(f"{outfile}",'wb') as p:
                p.write(file.content)
            
            # #The downloaded file is a zip file that contains reduced_measurement.nc, standard_measurement.nc, enhanced_measurement.nc
            # #We only extract and keep the standard_measurement.nc
            # if os.path.getsize(outfile) < 1024: 
            #     os.remove(outfile)
            #     continue
            
            # # with zipfile.ZipFile(outfile) as zobject:
            #     with zobject.open(product_names[i] +'/standard_measurement.nc') as zfile, open(outputFile_Dir + '\\' + product_names[i].split('.')[0] + '_standard.nc', 'wb') as f:
            #         shutil.copyfileobj(zfile,f)
            
            #delete the downloaded zip file
            # os.remove(outfile)

#function for downloading Sen3A data
def downloadSen3B(lake_shp: gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir, esa_user, esa_password):
    #download Sentinel-3 data from Copernicus Data Space Ecocystem using OData
    # base URL of the product catalogue
    catalogue_odata_url = "https://catalogue.dataspace.copernicus.eu/odata/v1"
    # search parameters
    collection_name = "SENTINEL-3"
    product_type = "SR_2_LAN_HY"
    timeliness = "NT"
        
    #format the start date and end date as string
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    
    #get lake extent
    #project the shapefile to WGS 1984 first. The spatial search is based on the latitude and longitude.
    lake_shp = lake_shp.to_crs(crs='epsg:4326')
    # lake_maxLat = lake_shp['MaxLat'].values[0]
    # lake_minLat = lake_shp['MinLat'].values[0]
    # lake_maxLon = lake_shp['MaxLon'].values[0]
    # lake_minLon = lake_shp['MinLon'].values[0]
    LakeBound=lake_shp.total_bounds
    lake_minLon = LakeBound[0]
    lake_maxLon = LakeBound[2]
    lake_minLat = LakeBound[1]
    lake_maxLat = LakeBound[3]
    
    #AOI is defined by the four corners of the lake extent
    aoi = 'POLYGON(('+ str(lake_minLon)+' '+ str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_minLat)+','+ str(lake_minLon)+' '+str(lake_minLat)+','+str(lake_minLon)+' '+str(lake_maxLat)+'))'
    #second polygon: ,(30.19 2.19, 31.4 2.19, 31.4 1.0, 30.19 1.0, 30.19 2.19)
  
    # relOrbit = 127
    #and Attributes/OData.CSC.IntegerAttribute/any(att:att/Name eq 'relativeOrbitNumber' and att/OData.CSC.IntegerAttribute/Value eq '{relOrbit}')
    #max_cloud_cover = 1
    #AOI is defined by the four corners of the lake extent
    # aoi = 'POLYGON(('+ str(lake_minLon)+' '+ str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_minLat)+','+ str(lake_minLon)+' '+str(lake_minLat)+','+str(lake_minLon)+' '+str(lake_maxLat)+'))'
    #second polygon: ,(30.19 2.19, 31.4 2.19, 31.4 1.0, 30.19 1.0, 30.19 2.19)
    # search_period_start = "2023-06-01T00:00:00.000Z"
    # search_period_end = "2023-06-10T00:00:00.000Z"

    #build search query
    search_query = f"{catalogue_odata_url}/Products?$filter=Collection/Name eq '{collection_name}' and contains(Name, 'S3B') and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'productType' and att/OData.CSC.StringAttribute/Value eq '{product_type}') and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'timeliness' and att/OData.CSC.StringAttribute/Value eq '{timeliness}') and OData.CSC.Intersects(area=geography'SRID=4326;{aoi}') and ContentDate/Start gt {start_date_str} and ContentDate/Start lt {end_date_str}&$top=999"

    #run the query and display the results
    response = requests.get(search_query).json()
    result = pd.DataFrame.from_dict(response["value"])

    if not result.empty:
        #select the products
        product_identifiers = result.iloc[:,1]
        product_names = result.iloc[:,2]

        # Get authentication token
        auth_server_url = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
        data = {
            "client_id": "cdse-public",
            "grant_type": "password",
            "username": esa_user,
            "password": esa_password,
        }
        response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
        access_token = json.loads(response.text)["access_token"]
        refresh_token = json.loads(response.text)["refresh_token"]

        #get session start time
        session_start_time = time.time()
        session_renew_time = session_start_time

        # Establish session
        session = requests.Session()
        # headers = {"Authorization": f"Bearer {access_token}"}
        session.headers["Authorization"] = f"Bearer {access_token}"
        #session.headers.update({'Authorization': f'Bearer {access_token}'})

        for i in range(len(product_identifiers)):
            product_nm = (product_names[i]).split('.')[0]+'_standard.nc'
            url = f"{catalogue_odata_url}/Products({product_identifiers[i]})/Nodes({product_names[i]})/Nodes(standard_measurement.nc)/$value"
            #print(url)
        
            response = session.get(url, allow_redirects=False)
            if response.status_code in (301, 302, 303, 307):
                url = response.headers["Location"]
                # response = session.get(url, allow_redirects=False)
            
            currentTime = time.time()
            time_sinceRenew =  session_renew_time
            time_sinceStart = currentTime - session_start_time
            
            #session times out in 10 minutes, and totally expires in 60 minutes
            if response.status_code in (401,403) or (time_sinceRenew >= 600 and time_sinceStart < 3600):
                data = {
                "client_id": "cdse-public",
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,        
                }
                response = requests.post(auth_server_url, data=data, verify=False, allow_redirects=False)
                access_token = json.loads(response.text)["access_token"]
                session = requests.Session()
                session.headers["Authorization"] = f"Bearer {access_token}"
                session_renew_time = time.time()
            
            if time_sinceStart >= 3600:
                data = {
                    "client_id": "cdse-public",
                    "grant_type": "password",
                    "username": esa_user,
                    "password": esa_password,
                }
                response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
                access_token = json.loads(response.text)["access_token"]
                refresh_token = json.loads(response.text)["refresh_token"]

                # Establish session
                session = requests.Session()
                # headers = {"Authorization": f"Bearer {access_token}"}
                session.headers["Authorization"] = f"Bearer {access_token}"        
                session_start_time = time.time()
            
            # session.headers.update(headers)
        
            #save the data to local directory
            outfile = os.path.join(outputFile_Dir, product_nm)
            if os.path.exists(outfile):
                continue
            
            #download the data
            file = session.get(url, verify=False, allow_redirects=True)
            
            with open(f"{outfile}",'wb') as p:
                p.write(file.content)
            
            # #The downloaded file is a zip file that contains reduced_measurement.nc, standard_measurement.nc, enhanced_measurement.nc
            # #We only extract and keep the standard_measurement.nc
            # if os.path.getsize(outfile) < 1024: 
            #     os.remove(outfile)
            #     continue
            
            # # with zipfile.ZipFile(outfile) as zobject:
            #     with zobject.open(product_names[i] +'/standard_measurement.nc') as zfile, open(outputFile_Dir + '\\' + product_names[i].split('.')[0] + '_standard.nc', 'wb') as f:
            #         shutil.copyfileobj(zfile,f)
            
            #delete the downloaded zip file
            # os.remove(outfile)

#function for downloading Sen3 data
def downloadSen3(lake_shp:gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir, esa_user, esa_password, UsePass = False):
    # lake_shp = gpd.read_file(lake_shp_pathName, drivers = 'shapefile')
    #download Sentinel-3 data from Copernicus Data Space Ecocystem using OData
    # base URL of the product catalogue
    catalogue_odata_url = "https://catalogue.dataspace.copernicus.eu/odata/v1"
    # search parameters
    collection_name = "SENTINEL-3"
    product_type = "SR_2_LAN___"
    timeliness = "NT"
        
    #format the start date and end date as string
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    
    #get lake extent
    #project the shapefile to WGS 1984 first. The spatial search is based on the latitude and longitude.
    lake_shp = lake_shp.to_crs(crs='epsg:4326')
    # lake_maxLat = lake_shp['MaxLat'].values[0]
    # lake_minLat = lake_shp['MinLat'].values[0]
    # lake_maxLon = lake_shp['MaxLon'].values[0]
    # lake_minLon = lake_shp['MinLon'].values[0]
    LakeBound=lake_shp.total_bounds
    lake_minLon = LakeBound[0]
    lake_maxLon = LakeBound[2]
    lake_minLat = LakeBound[1]
    lake_maxLat = LakeBound[3]
    
    #AOI is defined by the four corners of the lake extent
    aoi = 'POLYGON(('+ str(lake_minLon)+' '+ str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_minLat)+','+ str(lake_minLon)+' '+str(lake_minLat)+','+str(lake_minLon)+' '+str(lake_maxLat)+'))'
    #second polygon: ,(30.19 2.19, 31.4 2.19, 31.4 1.0, 30.19 1.0, 30.19 2.19)
    
    if UsePass == True:
        #divide the pass number by 2 to get the number used in data file name, round down to nearest whole number
        passNum_Sen3A = (np.array((lake_shp['Sen3A_Pass'].values[0]).split(','), dtype= int)//2).tolist()
        passNum_Sen3B = (np.array((lake_shp['Sen3B_Pass'].values[0]).split(','), dtype= int)//2).tolist()
        passNumStr_Sen3A = [format(x, '03d') for x in passNum_Sen3A]#convert it to str, e.g., 15 -> '015'
        passNumStr_Sen3B = [format(x, '03d') for x in passNum_Sen3B]
        
        for passNum in passNumStr_Sen3A:
            #build search query
            search_query = f"{catalogue_odata_url}/Products?$filter=Collection/Name eq '{collection_name}' and contains(Name, 'S3A') and contains(Name, '_{passNum}__') and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'productType' and att/OData.CSC.StringAttribute/Value eq '{product_type}') and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'timeliness' and att/OData.CSC.StringAttribute/Value eq '{timeliness}') and OData.CSC.Intersects(area=geography'SRID=4326;{aoi}') and ContentDate/Start gt {start_date_str} and ContentDate/Start lt {end_date_str}"
            
            # and contains(Name, '_{passNum}__') 
            # and Attributes/OData.CSC.IntegerAttribute/any(att:att/Name eq 'relativeOrbitNumber' and att/OData.CSC.IntegerAttribute/Value eq '{passNum}')
            
            #run the query and display the results
            response = requests.get(search_query).json()
            result = pd.DataFrame.from_dict(response["value"])
            
            # result_noDup = result.drop_duplicates(result.columns[2], keep='first', ignore_index=True)

            #select the products
            product_identifiers = result.iloc[:,1]
            product_names = result.iloc[:,2]

            # Get authentication token
            auth_server_url = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
            data = {
                "client_id": "cdse-public",
                "grant_type": "password",
                "username": esa_user,
                "password": esa_password,
            }
            response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
            access_token = json.loads(response.text)["access_token"]
            refresh_token = json.loads(response.text)["refresh_token"]

            #get session start time
            session_start_time = time.time()
            session_renew_time = session_start_time

            # Establish session
            session = requests.Session()
            # headers = {"Authorization": f"Bearer {access_token}"}
            session.headers["Authorization"] = f"Bearer {access_token}"
            #session.headers.update({'Authorization': f'Bearer {access_token}'})

            for i in range(len(product_identifiers)):
                product_nm = (product_names[i]).split('.')[0]+'_standard.nc'
                url = f"{catalogue_odata_url}/Products({product_identifiers[i]})/Nodes({product_names[i]})/Nodes(standard_measurement.nc)/$value"
                #print(url)
            
                response = session.get(url, allow_redirects=False)
                if response.status_code in (301, 302, 303, 307):
                    url = response.headers["Location"]
                    # response = session.get(url, allow_redirects=False)
                
                currentTime = time.time()
                time_sinceRenew =  session_renew_time
                time_sinceStart = currentTime - session_start_time
                
                #session times out in 10 minutes, and totally expires in 60 minutes
                if response.status_code in (401,403) or (time_sinceRenew >= 600 and time_sinceStart < 3600):
                    data = {
                    "client_id": "cdse-public",
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,        
                    }
                    response = requests.post(auth_server_url, data=data, verify=False, allow_redirects=False)
                    access_token = json.loads(response.text)["access_token"]
                    session = requests.Session()
                    session.headers["Authorization"] = f"Bearer {access_token}"
                    session_renew_time = time.time()
                
                if time_sinceStart >= 3600:
                    data = {
                        "client_id": "cdse-public",
                        "grant_type": "password",
                        "username": esa_user,
                        "password": esa_password,
                    }
                    response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
                    access_token = json.loads(response.text)["access_token"]
                    refresh_token = json.loads(response.text)["refresh_token"]

                    # Establish session
                    session = requests.Session()
                    # headers = {"Authorization": f"Bearer {access_token}"}
                    session.headers["Authorization"] = f"Bearer {access_token}"        
                    session_start_time = time.time()
                
                # session.headers.update(headers)
                
                #download the data
                file = session.get(url, verify=False, allow_redirects=True)
                
                #save the data to local directory
                outfile = os.path.join(outputFile_Dir, product_nm)
                with open(f"{outfile}",'wb') as p:
                    p.write(file.content)
                
                #The downloaded file is a zip file that contains reduced_measurement.nc, standard_measurement.nc, enhanced_measurement.nc
                #We only extract and keep the standard_measurement.nc
                if os.path.getsize(outfile) < 1024: 
                    os.remove(outfile)
                    continue
                
                # with zipfile.ZipFile(outfile) as zobject:
                #     with zobject.open(product_names[i] +'/standard_measurement.nc') as zfile, open(outputFile_Dir + '\\' + product_names[i].split('.')[0] + '_standard.nc', 'wb') as f:
                #         shutil.copyfileobj(zfile,f)
                
                # #delete the downloaded zip file
                # os.remove(outfile)
            
        for passNum in passNumStr_Sen3B:
            #build search query
            search_query = f"{catalogue_odata_url}/Products?$filter=Collection/Name eq '{collection_name}' and contains(Name, 'S3B') and contains(Name, '_{passNum}__') and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'productType' and att/OData.CSC.StringAttribute/Value eq '{product_type}') and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'timeliness' and att/OData.CSC.StringAttribute/Value eq '{timeliness}') and OData.CSC.Intersects(area=geography'SRID=4326;{aoi}') and ContentDate/Start gt {start_date_str} and ContentDate/Start lt {end_date_str}"
            
            # and contains(Name, '_{passNum}__') 
            # and Attributes/OData.CSC.IntegerAttribute/any(att:att/Name eq 'relativeOrbitNumber' and att/OData.CSC.IntegerAttribute/Value eq '{passNum}')
            
            #run the query and display the results
            response = requests.get(search_query).json()
            result = pd.DataFrame.from_dict(response["value"])
            
            # result_noDup = result.drop_duplicates(result.columns[2], keep='first', ignore_index=True)

            #select the products
            product_identifiers = result.iloc[:,1]
            product_names = result.iloc[:,2]

            # Get authentication token
            auth_server_url = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
            data = {
                "client_id": "cdse-public",
                "grant_type": "password",
                "username": esa_user,
                "password": esa_password,
            }
            response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
            access_token = json.loads(response.text)["access_token"]
            refresh_token = json.loads(response.text)["refresh_token"]

            #get session start time
            session_start_time = time.time()
            session_renew_time = session_start_time

            # Establish session
            session = requests.Session()
            # headers = {"Authorization": f"Bearer {access_token}"}
            session.headers["Authorization"] = f"Bearer {access_token}"
            #session.headers.update({'Authorization': f'Bearer {access_token}'})

            for i in range(len(product_identifiers)):
                product_nm = (product_names[i]).split('.')[0]+'_standard.nc'
                url = f"{catalogue_odata_url}/Products({product_identifiers[i]})/Nodes({product_names[i]})/Nodes(standard_measurement.nc)/$value"
                #print(url)
            
                response = session.get(url, allow_redirects=False)
                if response.status_code in (301, 302, 303, 307):
                    url = response.headers["Location"]
                    # response = session.get(url, allow_redirects=False)
                
                currentTime = time.time()
                time_sinceRenew =  session_renew_time
                time_sinceStart = currentTime - session_start_time
                
                #session times out in 10 minutes, and totally expires in 60 minutes
                if response.status_code in (401,403) or (time_sinceRenew >= 600 and time_sinceStart < 3600):
                    data = {
                    "client_id": "cdse-public",
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,        
                    }
                    response = requests.post(auth_server_url, data=data, verify=False, allow_redirects=False)
                    access_token = json.loads(response.text)["access_token"]
                    session = requests.Session()
                    session.headers["Authorization"] = f"Bearer {access_token}"
                    session_renew_time = time.time()
                
                if time_sinceStart >= 3600:
                    data = {
                        "client_id": "cdse-public",
                        "grant_type": "password",
                        "username": esa_user,
                        "password": esa_password,
                    }
                    response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
                    access_token = json.loads(response.text)["access_token"]
                    refresh_token = json.loads(response.text)["refresh_token"]

                    # Establish session
                    session = requests.Session()
                    # headers = {"Authorization": f"Bearer {access_token}"}
                    session.headers["Authorization"] = f"Bearer {access_token}"        
                    session_start_time = time.time()
                
                # session.headers.update(headers)
                
                #download the data
                file = session.get(url, verify=False, allow_redirects=True)
                
                #save the data to local directory
                outfile = os.path.join(outputFile_Dir, product_nm)
                with open(f"{outfile}",'wb') as p:
                    p.write(file.content)
                
                #The downloaded file is a zip file that contains reduced_measurement.nc, standard_measurement.nc, enhanced_measurement.nc
                #We only extract and keep the standard_measurement.nc
                if os.path.getsize(outfile) < 1024: 
                    os.remove(outfile)
                    continue
                
                # with zipfile.ZipFile(outfile) as zobject:
                #     with zobject.open(product_names[i] +'/standard_measurement.nc') as zfile, open(outputFile_Dir + '\\' + product_names[i].split('.')[0] + '_standard.nc', 'wb') as f:
                #         shutil.copyfileobj(zfile,f)
                
                # #delete the downloaded zip file
                # os.remove(outfile)
            
    else:    
        # relOrbit = 127
        #and Attributes/OData.CSC.IntegerAttribute/any(att:att/Name eq 'relativeOrbitNumber' and att/OData.CSC.IntegerAttribute/Value eq '{relOrbit}')
        #max_cloud_cover = 1
        #AOI is defined by the four corners of the lake extent
        # aoi = 'POLYGON(('+ str(lake_minLon)+' '+ str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_maxLat)+','+str(lake_maxLon)+' '+str(lake_minLat)+','+ str(lake_minLon)+' '+str(lake_minLat)+','+str(lake_minLon)+' '+str(lake_maxLat)+'))'
        #second polygon: ,(30.19 2.19, 31.4 2.19, 31.4 1.0, 30.19 1.0, 30.19 2.19)
        # search_period_start = "2023-06-01T00:00:00.000Z"
        # search_period_end = "2023-06-10T00:00:00.000Z"

        #build search query
        search_query = f"{catalogue_odata_url}/Products?$filter=Collection/Name eq '{collection_name}' and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'productType' and att/OData.CSC.StringAttribute/Value eq '{product_type}') and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'timeliness' and att/OData.CSC.StringAttribute/Value eq '{timeliness}') and OData.CSC.Intersects(area=geography'SRID=4326;{aoi}') and ContentDate/Start gt {start_date_str} and ContentDate/Start lt {end_date_str}"

        #run the query and display the results
        response = requests.get(search_query).json()
        result = pd.DataFrame.from_dict(response["value"])

        #select the products
        product_identifiers = result.iloc[:,1]
        product_names = result.iloc[:,2]

        # Get authentication token
        auth_server_url = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
        data = {
            "client_id": "cdse-public",
            "grant_type": "password",
            "username": esa_user,
            "password": esa_password,
        }
        response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
        access_token = json.loads(response.text)["access_token"]
        refresh_token = json.loads(response.text)["refresh_token"]

        #get session start time
        session_start_time = time.time()
        session_renew_time = session_start_time

        # Establish session
        session = requests.Session()
        # headers = {"Authorization": f"Bearer {access_token}"}
        session.headers["Authorization"] = f"Bearer {access_token}"
        #session.headers.update({'Authorization': f'Bearer {access_token}'})

        for i in range(len(product_identifiers)):
            product_nm = (product_names[i]).split('.')[0]+'_standard.nc'
            url = f"{catalogue_odata_url}/Products({product_identifiers[i]})/Nodes({product_names[i]})/Nodes(standard_measurement.nc)/$value"
            #print(url)
        
            response = session.get(url, allow_redirects=False)
            if response.status_code in (301, 302, 303, 307):
                url = response.headers["Location"]
                # response = session.get(url, allow_redirects=False)
            
            currentTime = time.time()
            time_sinceRenew =  session_renew_time
            time_sinceStart = currentTime - session_start_time
            
            #session times out in 10 minutes, and totally expires in 60 minutes
            if response.status_code in (401,403) or (time_sinceRenew >= 600 and time_sinceStart < 3600):
                data = {
                "client_id": "cdse-public",
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,        
                }
                response = requests.post(auth_server_url, data=data, verify=False, allow_redirects=False)
                access_token = json.loads(response.text)["access_token"]
                session = requests.Session()
                session.headers["Authorization"] = f"Bearer {access_token}"
                session_renew_time = time.time()
            
            if time_sinceStart >= 3600:
                data = {
                    "client_id": "cdse-public",
                    "grant_type": "password",
                    "username": esa_user,
                    "password": esa_password,
                }
                response = requests.post(auth_server_url, data=data, verify=True, allow_redirects=True)
                access_token = json.loads(response.text)["access_token"]
                refresh_token = json.loads(response.text)["refresh_token"]

                # Establish session
                session = requests.Session()
                # headers = {"Authorization": f"Bearer {access_token}"}
                session.headers["Authorization"] = f"Bearer {access_token}"        
                session_start_time = time.time()
            
            # session.headers.update(headers)
            
            #download the data
            file = session.get(url, verify=False, allow_redirects=True)
            
            #save the data to local directory
            outfile = os.path.join(outputFile_Dir, product_nm)
            with open(f"{outfile}",'wb') as p:
                p.write(file.content)
            
            #The downloaded file is a zip file that contains reduced_measurement.nc, standard_measurement.nc, enhanced_measurement.nc
            #We only extract and keep the standard_measurement.nc
            if os.path.getsize(outfile) < 1024: 
                os.remove(outfile)
                continue
            
            # with zipfile.ZipFile(outfile) as zobject:
                with zobject.open(product_names[i] +'/standard_measurement.nc') as zfile, open(outputFile_Dir + '\\' + product_names[i].split('.')[0] + '_standard.nc', 'wb') as f:
                    shutil.copyfileobj(zfile,f)
            
            #delete the downloaded zip file
            # os.remove(outfile)

def downloadJason3(lake_shp:gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir, path_cyc_date_list_csv):
    # lake_shp = gpd.read_file(lake_shp_pathName, drivers = 'shapefile')
    
    passNumStr_JA3 = (lake_shp['JA3_Pass'].values[0]).split(',')
    
    start_date = np.datetime64(start_date)
    end_date = np.datetime64(end_date)
    #load date range of JA3 cycles
    # ctypes.windll.user32.MessageBoxW(0, os.path.join(path_cyc_date_list_csv, 'JA3_Cycle_DateRange.csv'), "test", 1)
    df_cycle_timeRng = pd.read_csv((os.path.join(path_cyc_date_list_csv, 'JA3_Cycle_DateRange.csv')), parse_dates=['cycle_start','cycle_end'], date_format= '%Y-%m-%d')
    
    #establish ftp connection
    ftp_connection = FTP("ftp-oceans.ncei.noaa.gov")
    ftp_connection.login(user="",passwd="")
    #jason3/gdr/gdr/ contains empty cycle folders, using the gdr_f/gdr
    ftp_connection.cwd("nodc/data/jason3/gdr_f/gdr/")
    #save the parent directory
    parent_dir = ftp_connection.pwd()
    #get the list of cycles
    items = ftp_connection.nlst()
    cycles = []
    for item in items:
        if "." not in item:
            cycles.append(item)

    #update date range of JA3 cycles
    old_cycles = df_cycle_timeRng['cycle'].tolist()
    if len(old_cycles) < len(cycles): 
        for i in range (len(old_cycles), len(cycles)):
            ftp_connection.cwd(parent_dir)
            #change to the subfolder
            ftp_connection.cwd(cycles[i])
            
            #get cycle start and end date
            files = ftp_connection.nlst()
            file_first = files[0]
            file_last = files[len(files)-1]        
            cycle_startDate = datetime.strptime(file_first[20:24]+'-'+ file_first[24:26] +'-'+ file_first[26:28], '%Y-%m-%d')
            cycle_endDate = datetime.strptime(file_last[20:24]+'-'+ file_last[24:26] +'-'+ file_last[26:28], '%Y-%m-%d')
            
            df_cycle_timeRng.loc[len(df_cycle_timeRng.index)] = [cycles[i], cycle_startDate, cycle_endDate]
        
        df_cycle_timeRng.to_csv('JA3_Cycle_DateRange.csv', index=False)

    #find the cycles according to user specified start and end time
    # ctypes.windll.user32.MessageBoxW(0, str(type(df_cycle_timeRng.loc['cycle_end'][0])), "test", 1)
    cycles_sel = df_cycle_timeRng.loc[(df_cycle_timeRng['cycle_end'] >= start_date) & (df_cycle_timeRng['cycle_start'] <= end_date)].copy().reset_index(drop=True)
    cycles_need = cycles_sel['cycle'].tolist()

    #search the data in each cycle folder with specified pass numbers
    if passNumStr_JA3 is not None: 
        for cycle in cycles_need:
            ftp_connection.cwd(parent_dir)
            #change to the subfolder
            ftp_connection.cwd(cycle)
            for eachPass in passNumStr_JA3:
                #search file for each pass
                files = ftp_connection.nlst('*_' + eachPass+ '_*')
                
                if len(files) == 0: continue
                
                for eachFile in files:
                    #download the data
                    local_filename = outputFile_Dir + '\\' + eachFile
                    if os.path.exists(local_filename):
                        continue
                    
                    with open(local_filename, 'wb') as f:
                        ftp_connection.retrbinary('RETR %s' % eachFile, f.write)
    ftp_connection.quit() 

#use lake polygon to identify Jason-3 pass numbers
def downloadJason3_new(lake_shp: gpd.GeoDataFrame, start_date: datetime, end_date: datetime, outputFile_Dir, this_plugin_dir):
    #identify the pass number for this lake
    passNumStr_JA3_interleaved, passNumStr_JA3_nominal = identifyJA3Pass(lake_shp, this_plugin_dir)
    passNumStr_JA3_interleaved = passNumStr_JA3_interleaved.split(',')
    passNumStr_JA3_nominal = passNumStr_JA3_nominal.split(',')
    
    #date that Jason-3 were maneuvered to interleaved orbit
    # maneu_date = datetime(2022,4,7)
    #the cycle that contains maneuver date
    maneu_cycle = 227
    
    start_date = np.datetime64(start_date)
    end_date = np.datetime64(end_date)
    
    #load date range of JA3 cycles
    df_cycle_timeRng = pd.read_csv((os.path.join(this_plugin_dir, 'JA3_Cycle_DateRange.csv')), parse_dates=['cycle_start','cycle_end'], date_format= '%Y-%m-%d')
    
    #establish ftp connection
    ftp_connection = FTP("ftp-oceans.ncei.noaa.gov")
    ftp_connection.login(user="",passwd="")
    #jason3/gdr/gdr/ contains empty cycle folders, using the gdr_f/gdr
    ftp_connection.cwd("nodc/data/jason3/gdr_f/gdr/")
    #save the parent directory
    parent_dir = ftp_connection.pwd()
    #get the list of cycles
    items = ftp_connection.nlst()
    cycles = []
    for item in items:
        if "." not in item:
            cycles.append(item)

    #update date range of JA3 cycles
    old_cycles = df_cycle_timeRng['cycle'].tolist()
    if len(old_cycles) < len(cycles): 
        for i in range (len(old_cycles), len(cycles)):
            ftp_connection.cwd(parent_dir)
            #change to the subfolder
            ftp_connection.cwd(cycles[i])
            
            #get cycle start and end date
            files = ftp_connection.nlst()
            file_first = files[0]
            file_last = files[len(files)-1]        
            cycle_startDate = datetime.strptime(file_first[20:24]+'-'+ file_first[24:26] +'-'+ file_first[26:28], '%Y-%m-%d')
            cycle_endDate = datetime.strptime(file_last[20:24]+'-'+ file_last[24:26] +'-'+ file_last[26:28], '%Y-%m-%d')
            
            df_cycle_timeRng.loc[len(df_cycle_timeRng.index)] = [cycles[i], cycle_startDate, cycle_endDate]
        
        df_cycle_timeRng.to_csv('JA3_Cycle_DateRange.csv', index=False)
    
    #find the cycles according to user specified start and end time
    cycles_sel = df_cycle_timeRng.loc[(df_cycle_timeRng['cycle_end'] >= start_date) & (df_cycle_timeRng['cycle_start'] <= end_date)].copy().reset_index(drop=True)
    cycles_need = cycles_sel['cycle'].tolist()

    #search the data in each cycle folder with specified pass numbers
    # if (passNumStr_JA3_interleaved is not None) or (passNumStr_JA3_nominal is not None): 
    for cycle in cycles_need:
        ftp_connection.cwd(parent_dir)
        #change to the subfolder
        ftp_connection.cwd(cycle)
        cycle_num = int(cycle[5:])
        if cycle_num <= maneu_cycle: passNumStr_JA3 = passNumStr_JA3_nominal
        else: passNumStr_JA3 = passNumStr_JA3_interleaved
        
        if passNumStr_JA3 is not None:
            for eachPass in passNumStr_JA3:
                #search file for each pass
                files = ftp_connection.nlst('*_' + eachPass+ '_*')
                
                if len(files) == 0: continue
                
                for eachFile in files:
                    #test if the file date is exactly within the range specified by user
                    file_date = datetime.strptime(eachFile[20:24]+'-'+ eachFile[24:26] +'-'+ eachFile[26:28], '%Y-%m-%d')
                    file_date = np.datetime64(file_date)
                    if not ((file_date >= start_date) and (file_date <= end_date)): continue

                    #test if the data is already there
                    local_filename = outputFile_Dir + '\\' + eachFile
                    if os.path.exists(local_filename): continue
                    
                    #download the data
                    with open(local_filename, 'wb') as f:
                        ftp_connection.retrbinary('RETR %s' % eachFile, f.write)
    
    ftp_connection.quit()

#function for identifying jason-3 pass
def identifyJA3Pass(lake_shp: gpd.GeoDataFrame, this_plugin_dir):
    ja3Pass_shp_int = gpd.read_file(os.path.join(this_plugin_dir, 'TP_Jason_Interval.shp'))
    ja3Pass_shp_nom = gpd.read_file(os.path.join(this_plugin_dir, 'TP_Jason_Nominal.shp'))
    
    #create a copy of lake shapefile
    lake_shp_copy = lake_shp.copy(deep=True)
    #convert crs of lake polygon to the same with the pass shapefiles.
    if lake_shp_copy.crs != ja3Pass_shp_int.crs:
        lake_shp_copy = lake_shp_copy.to_crs(ja3Pass_shp_int.crs)
    
    lake_poly = lake_shp_copy.geometry.iloc[0]  
    
    int_passes = ja3Pass_shp_int[ja3Pass_shp_int.intersects(lake_poly)]        
    nom_passes = ja3Pass_shp_nom[ja3Pass_shp_nom.intersects(lake_poly)]
    #pad the Track numbers with leading zeros so that each is exactly 3 digits — for example:
    # 1 → "001"
    # 12 → "012"
    # 205 → "205"
    int_passes_str = ",".join(f"{int(t):03d}" for t in int_passes['Track'].tolist())
    nom_passes_str = ",".join(f"{int(t):03d}" for t in nom_passes['Track'].tolist())
    
    return int_passes_str, nom_passes_str

